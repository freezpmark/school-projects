/*
Na za�iatku m�te pr�zdnu mno�inu cel�ch ��sel. Postupne do nej vklad�te ��sla. Pre ka�d� vkladan� ��slo zistite, ak� ��slo v mno�ine je k nemu najbli��ie. Ak sa vkladan� ��slo v mno�ine u� nach�dza, vyp�te k nemu najbli��ie ��slo (r�zne od vkladan�ho ��sla). Ak existuj� dve r�zne najbli��ie ��sla, vyp�te men�ie z nich. Ak je mno�ina pr�zdna, vyp�te -1.

�pecifik�cia vstupu: Na vstupe je nieko�ko kladn�ch cel�ch ��sel, ktor� nepresahuj� hodnotu 2^31.

�pecifik�cia v�stupu: Pre ka�d� ��slo na vstupe vyp�te k nemu doteraz najbli��ie ��slo.

Uk�ka vstupu:
5
3
2
1
3
V�stup pre uk�kov� vstup:
-1
5
3
2
2
*/

#include<stdio.h>
#include<stdlib.h>

// An AVL tree node
struct node
{
    int value;
    struct node *left;
    struct node *right;
    int height;
};

void findPreSuc(struct node *root, struct node **pre, struct node **succ, int value)
{
    if(root == NULL) return;

    if(root->value == value) {
        if(root->left != NULL) {
            struct node *temp = root->left;
            while(temp->right)
                temp = temp->right;
            *pre = temp;
        }

        if(root->right != NULL) {
            struct node *temp = root->right;
            while(temp->left)
                temp = temp->left;
            *succ = temp;
        }
        return;
    }

    if(root->value > value) {
        *succ = root;
        findPreSuc(root->left, pre, succ, value);
    }
    else {
        *pre = root;
        findPreSuc(root->right, pre, succ,value);
    }
}

// A utility function to get maximum of two integers
int max(int a, int b);

// A utility function to get height of the tree
int height(struct node *N)
{
    if (N == NULL)
        return 0;
    return N->height;
}

// A utility function to get maximum of two integers
int max(int a, int b)
{
    return (a > b)? a : b;
}

struct node* newNode(int value)
{
    struct node* node = (struct node*)
                        malloc(sizeof(struct node));
    node->value    = value;
    node->left   = NULL;
    node->right  = NULL;
    node->height = 1;  // new node is initially added at leaf
    return(node);
}

struct node *rightRotate(struct node *y)
{
    struct node *x = y->left;
    struct node *T2 = x->right;

    x->right = y;
    y->left = T2;

    y->height = max(height(y->left), height(y->right))+1;
    x->height = max(height(x->left), height(x->right))+1;

    return x;
}

struct node *leftRotate(struct node *x)
{
    struct node *y = x->right;
    struct node *T2 = y->left;

    y->left = x;
    x->right = T2;

    x->height = max(height(x->left), height(x->right))+1;
    y->height = max(height(y->left), height(y->right))+1;

    return y;
}

int getBalance(struct node *N)
{
    return height(N->left) - height(N->right);
}

struct node* insert(struct node* node, int value)
{
    if (node == NULL)
        return(newNode(value));

    if(value == node->value)
        return node;
    if (value < node->value)
        node->left  = insert(node->left, value);
    else
        node->right = insert(node->right, value);

    node->height = max(height(node->left), height(node->right)) + 1;

    int balance = getBalance(node);


    if (balance > 1 && value < node->left->value)
        return rightRotate(node);

    if (balance < -1 && value > node->right->value)
        return leftRotate(node);

    if (balance > 1 && value > node->left->value) {
        node->left =  leftRotate(node->left);
        return rightRotate(node);
    }

    if (balance < -1 && value < node->right->value) {
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }

    return node;
}


void preOrder(struct node *root)
{
    if(root != NULL)
    {
        printf("%d ", root->value);
        preOrder(root->left);
        preOrder(root->right);
    }
}


int main()
{
    struct node *root = NULL;
    int n;

    while(scanf("%d", &n) > 0){
        root = insert(root, n);
        struct node *pre = NULL, *succ = NULL;
        findPreSuc(root, &pre, &succ, n);

        if(pre == NULL && succ == NULL)
            printf("-1\n");

        if(pre != NULL && succ != NULL) {
            if(abs(pre->value - n) <= abs(succ->value -n))
                printf("%d\n", pre->value);
            else printf("%d\n", succ->value);
        }

        if(pre != NULL && succ == NULL)
            printf("%d\n", pre->value);

        if(succ != NULL && pre == NULL)
            printf("%d\n", succ->value);
    }

  return 0;
}
