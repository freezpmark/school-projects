/*
P�smenkov� strom je stromov� d�tov� �trukt�ra, v ktorej ka�d� uzol m� pr�ve jedn�ho rodi�a a viacero dc�rskych uzlov pod�a po�tu p�smen v abecede.

Zauj�mav� a u�ito�n� vlastnos� p�smenkov�ho stromu je, �e slov� so spolo�n�m prefixom zdie�aj� spolo�n� cestu v strome od kore�a po posledn� spolo�n� p�smeno v spolo�nom prefixe.

�pecifik�cia vstupu: Na vstupe je nieko�ko slov (najviac 10000), ktor� maj� d�ku najviac 20. Ka�d� slovo obsahuje iba ve�k� p�smen� anglickej abecedy.

�pecifik�cia v�stupu: Zistite, ak� najdlh�� spolo�n� prefix m� �ubovo�n� dvojica t�chto slov a toto ��slo vyp�te na v�stup.

Uk�ka vstupu:
SLON
MASLO
SILONKY
MAPA
MASKA
V�stup pre uk�kov� vstup:
3
*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#define hLetters ('Z' - 'A' + 1)

typedef struct node{
	int num;
	struct node ** children;
} NODE;

NODE * createNode(){
	int i;
	NODE * node = (NODE *)malloc(sizeof(NODE));
	node->num = 0;
	node->children = (NODE **)malloc(hLetters * sizeof(NODE *));

	for(i = 0 ; i < hLetters ; i++)
		node->children[i] = NULL;
	return node;
}

NODE * addWord(NODE * node, char * word){
	int num = word[0] - 'A';

	if(node->children[num] == NULL)
		node->children[num] = createNode();

	node->children[num]->num++;

	if(isalpha(word[1]))
		node->children[num] = addWord(node->children[num], ++word);

	return node;
}

int getLongestPrefix(NODE * node, int depth){
	int max = depth, buff, i;
	for(i = 0 ; i < hLetters ; i++)
		if(node->children[i] != NULL){
			if(node->children[i]->num < 2)
				continue;
			buff = getLongestPrefix(node->children[i], depth + 1);

			if(buff > max)
				max = buff;
		}
    if(max > depth)
        return max;
    else
        return depth;
}


int main(){
	char word[50];
	int i = 0;
	NODE * firstNode = createNode();

	while((scanf("%s", word) > 0) && (i++ < 50000))
		firstNode = addWord(firstNode, word);

	printf("%d\n",getLongestPrefix(firstNode, 0));
	return 0;
}
