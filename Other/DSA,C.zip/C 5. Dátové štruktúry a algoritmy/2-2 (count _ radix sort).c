/*
Jakubko sa hral s kockami. Na narodeniny dostal sadu kociek, ktor� obsahuje N (N <= 1 000 000) kociek, ka�d� m� na sebe nap�san� nejak� ��slo od 1 do N^2. ��sla nap�san� na kock�ch s� r�zne.

Kocky boli v balen� rozh�dzan� a Jakubko by sa chcel nau�i�, ktor� ��slo je v��ie od ktor�ho. Pom��te Jakubkovi a usporiadajte kocky pod�a ��sel vzostupne.

Va�ou �lohou je implementova� funkciu v nasledovnom tvare:

// Utriedi n cisel v poli a
void utried(int *a, int n);
Pr�klad postupnosti:
N = 6
10 9 8 1 2 3
Utrieden� postupnos�:
1 2 3 8 9 10
Pozn�mka: Algoritmus, ktor� ��sla usporiada �tandardn�m algoritmom v �ase O(n log n) je pomal�. Rie�enie mus� be�a� v �ase O(n).
*/
#include <stdio.h>
#include <stdlib.h>

// Utriedi n cisel v poli a
void utried(int *a, int n)
{
    int i, max = 0, passing;
    for(i = 0; i < n; i++) {
        if(max < a[i])
            max = a[i];
    }

    for (passing = 1; max / passing > 0; passing *= 256) {

        int buff[n];
        int pom[256];// = {0};
        for(i = 0; i < 256; i++)
            pom[i] = 0;

    // poming sort princip
        for (i = 0; i < n; i++)
            pom[(a[i] / passing) % 256]++;  // diff

        for (i = 1; i < 256; i++)
            pom[i] = pom[i] + pom[i-1];

        for (i = n-1; i >= 0; i--)     // diff
            buff[pom[(a[i] / passing) % 256]-- - 1] = a[i];

        for (i = 0; i < n; i++)
            a[i] = buff[i];
    }
}


int main(void)
{
  int i, *x, n;

  scanf("%d", &n);
  x = (int*)malloc(n * sizeof(int));
  for (i = 0; i < n; i++)
    scanf("%d", &x[i]);

  utried(x, n);

  printf("%d", x[0]);
  for (i = 1; i < n; i++)
  {
    printf(" %d", x[i]);
    if (x[i-1] > x[i])
    {
      printf(" -- CHYBA\n");
      return 0;
    }
  }
  printf("\n");

  printf("OK\n");
  return 0;
}
