/*
Jakubko st�le nie�o vym���a... rozhodol sa, �e rozbehne podnikanie, a ked�e sam�mu sa podnik� �a�ko, 
prehovoril svojho bra�eka J�na Rastislava, �e bud� rozn�a� dar�eky. Podnikate�sk� pl�n je zalo�en� 
na nezabudnute�nom z�itku pri preberan� dar�eku. Dar�eky sa preto starostliovo zabalia 
a rozn�aj� po jednom. Pom��te teraz bratom napl�nova� rozn�anie dar�ekov tak, aby roznos bol ��m sk�r dokon�en�.

Mesto, v ktorom dar�eky rozn�aj�, je s�visl� graf, vrcholy s� domy a hrany s� ulice medzi domami, 
ka�d� hrana m� d�ku ko�ko trv� prechod touto hranou �ubovo�n�m smerom. 
Podnikatelia maj� svoju centr�lu vo vrchole 1 a rozn�aj� dar�eky do ostatn�ch vrcholov. 
Najsk�r v�dy pobalia dar�eky a potom ich za�n� rozn�a�. S� nato dvaja, 
v ka�dom okamihu m��e ma� ka�d� z nich v ruk�ch najviac jeden dar�ek a je na ceste z centr�ly 
do miesta ur�enia alebo sa vracia na centr�lu (po �al�� dar�ek). Pr�cu si rozdelia tak, 
aby bola �o najsk�r hotov�; pracovn� podmienky s� �a�k�, rozn�aj� bez n�roku na oddych. 
Pom��te bratom a zistite, za ak� najkrat�� �as bud� v�etky dar�eky roznesen� a obaja sa 
vr�tia na centr�lu k spolo�n�mu obedu.

Vstup: �tandardn� vstup obsahuje zadan� graf -- po�et domov (vrcholov grafu) N < 100 
a po�et ul�c (hr�n grafu) M < 5000. Nasleduje M troj�c A B D, ktor� opisuj� cestu medzi 
vrcholmi A a B, pri�om d�ka ko�ko trv� prechod po hrane je D < 50 �asov�ch jednotiek. 
Nasleduje po�et dar�ekov na roznos K < 100 a K ��sel domov do ktor�ch treba pojednom porozn�a� dar�eky.

V�stup: Na �tandardn� v�stup vyp�te najkrat�� �as za ktor� dok�u dar�eky po jednom roznies� 
a vr�ti� sa nasp� do centr�ly.

Uk�ka vstupu:
5 6
2 1 5
3 4 5
5 3 10
1 3 20
3 2 5
4 5 10
5
2
3
3
4
5
V�stup pre uk�kov� vstup:
60
Vysvetlenie: jeden bude roznesie do 2, 3 a 4, druh� roznesie do 3 a 5
*/

// uloha-9-1.c -- Tyzden 9 - Uloha 1
// Peter Markus, 14.11.2016 09:29:57

// A C / C++ program for Dijkstra's single source shortest path algorithm.
// The program is for adjacency matrix representation of the graph

#include <stdio.h>
#include <limits.h>

// Number of vertices in the graph
#define V 9
int M;
// A utility function to find the vertex with minimum distance value, from
// the set of vertices not yet included in shortest path tree
int minDistance(int dist[], int sptSet[])
{
   // Initialize min value
   int min = INT_MAX, min_index, v;

   for (v = 0; v < M; v++)
     if (sptSet[v] == 0 && dist[v] <= min)
         min = dist[v], min_index = v;

   return min_index;
}
// A utility function to print the constructed distance array
void printSolution(int dist[], int n)
{
   printf("Vertex Distance from Source\n");
   int i;
   for (i = 0; i < M; i++)
      printf("%d \t\t %d\n", i, dist[i]);
}


// A utility function that returns maximum of two integers
int max(int a, int b) { return (a > b)? a : b; }

// Returns the maximum value that can be put in a knapsack of capacity W
int knapSack(int W, int wt[], int val[], int n)
{
   int i, w;
   int K[n+1][W+1];

   // Build table K[][] in bottom up manner
   for (i = 0; i <= n; i++) {
       for (w = 0; w <= W; w++) {
           if (i==0 || w==0)
               K[i][w] = 0;
           else if (wt[i-1] <= w)
                 K[i][w] = max(val[i-1] + K[i-1][w-wt[i-1]],  K[i-1][w]);
           else
                 K[i][w] = K[i-1][w];
       }
   }

   return K[n][W];
}

// Funtion that implements Dijkstra's single source shortest path algorithm
// for a graph represented using adjacency matrix representation
void dijkstra(int graph[M][M], int src)
{
     int dist[M];     // The output array.  dist[i] will hold the shortest
                      // distance from src to i

     int sptSet[M]; // sptSet[i] will true if vertex i is included in shortest
                     // path tree or shortest distance from src to i is finalized

     // Initialize all distances as INFINITE and stpSet[] as false
     int i;
     for (i = 0; i < M; i++)
        dist[i] = INT_MAX, sptSet[i] = 0;

     // Distance of source vertex from itself is always 0
     dist[src] = 0;

     // Find shortest path for all vertices
     int count;
     for (count = 0; count < M-1; count++) {
       // Pick the minimum distance vertex from the set of vertices not
       // yet processed. u is always equal to src in first iteration.
       int u = minDistance(dist, sptSet);

       // Mark the picked vertex as processed
       sptSet[u] = 1;

       // Update dist value of the adjacent vertices of the picked vertex.
       int v;
       for (v = 0; v < M; v++)

         // Update dist[v] only if is not in sptSet, there is an edge from
         // u to v, and total weight of path from src to  v through u is
         // smaller than current value of dist[v]
         if (!sptSet[v] && graph[u][v] && dist[u] != INT_MAX
                                       && dist[u]+graph[u][v] < dist[v])
            dist[v] = dist[u] + graph[u][v];
     }

     // print the constructed distance array

     //printSolution(dist, M);
     /*
     for(i = 0; i < M; i++)
        printf("%d ", dist[i]);
     printf("\n\n");*/


     int gifts, buff, kapa = 0;

     scanf("%d", &gifts);
     int pole[gifts-1];

     for(i = 0; i < gifts; i++) {
        scanf("%d", &buff);
        pole[i] = dist[buff];
        kapa += dist[buff];
     }

     if(kapa % 2 == 0)
        kapa = kapa/2;
     else {
        kapa = kapa/2;
        kapa++;
     }
     printf("%d", (knapSack(kapa, pole, pole, M))*2);
/*
     printf("\n\n");
     for(i = 0; i < M; i++)
        printf("%d ", dist[i]);
     printf("\n\n");
*/
}

// driver program to test above function
int main()
{
    int N, i, j;
    int a, b, c;
    scanf("%d", &M);
    scanf("%d", &N);
    M++;

    int mapa[M][M];
    for(i = 0; i < M; i++)
        for(j = 0; j < M; j++)
            mapa[i][j] = 0;

    for(i = 0; i < N; i++) {
        scanf("%d %d %d", &a, &b, &c);
        mapa[a][b] = mapa[b][a] = c;
    }

    dijkstra(mapa, 1);

    return 0;
}
