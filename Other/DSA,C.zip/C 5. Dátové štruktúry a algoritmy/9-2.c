/*
Jakubko si doprial dovolenku v takej zvl�tnej krajine. Rozhliadol sa do�ava, rozhliadol sa doprava, 
a �o nevid�? Nevid� ni�, nebol v nej �iaden kopec, v�etko sam� rovina, ale zato ve�a kr�sny miest. :) 
Komplikovan� politick� situ�cia e�te neumo�nila dostava� v krajine cestn� sie� do v�etk�ch t�chto 
miest a preto vl�da rozm���a ako by najefekt�vnej�ie dostava existuj�ci cestn� sie� tak, 
aby sa z ka�d�ho mesta dalo dosta� do ka�d�ho �al�ieho po ceste. Ide o strategick� z�ujem 
a s v�kupom pozemkov nebude najmen�� probl�m. Ke�e je krajina �plne ploch� stava� bud� len priame cesty. 
Jakubko teraz h�ta nad mapou tejto krajiny a rozm���a ko�ko kilometrov ciest bud� musie� v krajine postavi�.

Pom��te Jakubkovi a pre mapu krajiny -- s�radnice miest a zoznam existuj�cich cestn�ch spojen� -- 
zistite najmen�iu d�ku ciest, ktor� musia dostava�, aby sa medzi mestami dalo pohybova� po cest�ch.

Vstup: �tandardn� vstup obsahuje opis situ�cie v krajine: ��slo N < 1000 (po�et miest) 
a N dvoj�c cel�ch ��sel x-ov� a y-ov� s�radnica mesta, ��slo M < 5000 (po�et existuj�cich ciest)
 a M dvoj�c ��sel miest, ktor� sp�ja cesta.

V�stup: Na �tandardn� v�stup vyp�te d�ku ciest, ktor� musia e�te postavi�, aby prepojili v�etky mest�, 
zaokr�hlen� na tri desatinn� miesta.

Uk�ka vstupu:
9
1 5
0 0
3 2
4 5
5 1
0 4
5 2
1 2
5 3
3
1 3
9 7
1 2
2 3
V�stup pre uk�kov� vstup:
8.650
*/


// uloha-9-2.c -- Tyzden 9 - Uloha 2
// Peter Markus, 14.11.2016 09:30:48

// A C / C++ program for Prim's Minimum Spanning Tree (MST) algorithm.
// The program is for adjacency matrix representation of the graph

#include <stdio.h>
#include <limits.h>

// Number of vertices in the graph

int V;
// A utility function to find the vertex with minimum key value, from
// the set of vertices not yet included in MST
double minKey(double key[], int mstSet[])
{
   // Initialize min value
   double min = INT_MAX, min_index;
    int v;

   for (v = 0; v < V; v++)
     if (mstSet[v] == 0 && key[v] < min)
         min = key[v], min_index = v;

   return min_index;
}

// A utility function to print the constructed MST stored in parent[]
void printMST(int parent[], int n, double graph[V][V])
{

   //printf("Edge   Weight\n");
   int i;
   double sum = 0;
   for (i = 1; i < V; i++) {
      //printf("%d - %d    %.3lf \n", parent[i], i, graph[i][parent[i]]);
      sum +=  graph[i][parent[i]];
   }
   printf("%.3lf", sum);
}

// Function to construct and print MST for a graph represented using adjacency
// matrix representation
void primMST(double graph[V][V])
{
     int parent[V]; // Array to store constructed MST
     double key[V];   // Key values used to pick minimum weight edge in cut
     int mstSet[V];  // To represent set of vertices not yet included in MST

     // Initialize all keys as INFINITE
     int i, count, v;
     for (i = 0; i < V; i++)
        key[i] = INT_MAX, mstSet[i] = 0;

     // Always include first 1st vertex in MST.
     key[0] = 0;     // Make key 0 so that this vertex is picked as first vertex
     parent[0] = -1; // First node is always root of MST

     // The MST will have V vertices
     for (count = 0; count < V-1; count++)
     {
        // Pick the minimum key vertex from the set of vertices
        // not yet included in MST
        int u = minKey(key, mstSet);

        // Add the picked vertex to the MST Set
        mstSet[u] = 1;

        // Update key value and parent index of the adjacent vertices of
        // the picked vertex. Consider only those vertices which are not yet
        // included in MST
        for (v = 0; v < V; v++)

           // graph[u][v] is non zero only for adjacent vertices of m
           // mstSet[v] is 0 for vertices not yet included in MST
           // Update the key only if graph[u][v] is smaller than key[v]
          if (graph[u][v] && mstSet[v] == 0 && graph[u][v] <  key[v])
             parent[v]  = u, key[v] = graph[u][v];
     }

     // print the constructed MST
     printMST(parent, V, graph);
}

struct mesto {
    int x;
    int y;
}MESTO;

// driver program to test above function
int main()
{
    int x, y, i, j, a, b, pom;
    double dlzka;

    scanf("%d", &V);
    struct mesto mesta[V];
    for(i = 0; i < V; i++)
        scanf("%d %d", &mesta[i].x, &mesta[i].y);

    double pole[V][V];
    for(i = 0; i < V; i++) {
        for(j = 0; j < V; j++) {
            if (i == j)
                pole[i][j] = 0;
            else {
                x = mesta[i].x - mesta[j].x;
                y = mesta[i].y - mesta[j].y;
                dlzka = pow(x, 2) + pow(y, 2);
                pole[i][j] = pole[j][i] = sqrt(dlzka);
            }
        }
    }

    scanf("%d", &pom);
    for(i = 0; i < pom; i++) {
        scanf("%d %d", &a, &b);
        a--; b--;
        pole[a][b] = pole[b][a] = 0.0000001;
    }

/*
    for(i = 0; i < V; i++) {
        for(j = 0; j < V; j++) {
                if(i == j)
                 printf("%.3lf ", pole[i][j]);
        else
            printf("%.3lf ", pole[i][j]);
        }
        printf("\n");
    }
    printf("\n\n");
*/

   /* Let us create the following graph
          2    3
      (0)--(1)--(2)
       |   / \   |
      6| 8/   \5 |7
       | /     \ |
      (3)-------(4)
            9          */
            /*
   int graph[V][V] = {{0, 2, 0, 6, 0},
                      {2, 0, 3, 8, 5},
                      {0, 3, 0, 0, 7},
                      {6, 8, 0, 0, 9},
                      {0, 5, 7, 9, 0},
                     };
*/
    // Print the solution
    primMST(pole);

    return 0;
}
