/*
Jakubko sa hral s číslami. Na papierik si napísal do radu rôzne čísla, a všimol si, že niekedy je väčšie číslo napísane v rade skôr ako nejaké menšie číslo. Zaujíma ho, koľko je takých neusporiadaných dvojíc.

Vašou úlohou je implementovať funkciu v nasledovnom tvare:

// vrati pocet neusporiadaných dvojic
long pocet_neusporiadanych_dvojic(int *a, int n);
Poznámka: Postupnosť čísel môžete vo funkcii preusporiadať.

Príklad postupnosti:
N = 6 (počet čísel)
3 2 1 6 5 4

Počet neusporiadaných dvojíc: 6
[sú to dvojice (3,2), (3,1), (2,1), (6,5), (6,4), (5,4)]
*/

// uloha-2-3.c -- Tyzden 2 - Uloha 3
// Peter Markus, 26.9.2016 10:21:11

#include <stdio.h>
#include <stdlib.h>

// vrati pocet neusporiadaných dvojic

/*
Pri spájaní vyberáme (podľa veľkosti)
prvky z prvej alebo druhej postupnosti.
Keď pri spájaní vyberieme prvok X z druhej postupnosti,
do celkového počtu neusporiadaných dvojíc započítame
počet zostávajúcich prvkov v prvej postupnosti
(z ktorými všetkými X tvorí neusporiadanú dvojicu,
 a teda počítame tieto dvojice rýchlejšie ako po jednom).
*/

// merge sort s dvojicami

int sort(int a[], int left, int mid, int right, int pocet)
{
    int i, j, k;
    int pomL = mid-left+1;  //koniec - zaciatok (pocet prvkov vlavo)
    int pomR = right-mid;   //pocet prvkov vpravo
    int L[pomL], R[pomR];

    for (i = 0; i < pomL; i++)  // nahodenie hodnot z pola 'a'
        L[i] = a[left+i];
    for (j = 0; j < pomR; j++)
        R[j] = a[mid+1+j];

    for(i = j = 0, k = left; i < pomL && j < pomR; k++)    // k = zaciatok
        if (L[i] <= R[j])
            a[k] = L[i++];
        else {
            a[k] = R[j++];
            pocet += pomL - i;
        }

    while (i < pomL)
        a[k++] = L[i++];

    while (j < pomR)
        a[k++] = R[j++];

    return pocet;
}


long merge(int *a, int left, int right, int pocet)
{
    if(left < right) {
        int mid = (left+right)/2;
        pocet = merge(a, left, mid, pocet);
        pocet = merge(a, mid+1, right, pocet);
        pocet += sort(a, left, mid, right, 0);
    }
    return pocet;
}


long pocet_neusporiadanych_dvojic(int *a, int n)
{
    return merge(a, 0, n-1, 0);
}

int main(void)
{
  int i, *x, n;

  scanf("%d", &n);
  x = (int*)malloc(n * sizeof(int));
  for (i = 0; i < n; i++)
    scanf("%d", &x[i]);

  printf("Pocet neusporiadanych dvojic: %ld\n", pocet_neusporiadanych_dvojic(x, n));

  for(i = 0; i < n; i++)
    printf("%d ", x[i]);
  return 0;
}
