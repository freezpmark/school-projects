// uloha-3-1.c -- Tyzden 3 - Uloha 1
// Peter Markus, 3.10.2016 15:45:54
/*
Uva�ujte bin�rny vyh�ad�vac� strom. Na vstupe je dan�ch nieko�ko ��sel, ktor� postupne vklad�te do tohto stromu. Strom nevyva�ujte. Pre ka�d� ��slo zistite, ako hlboko je v strome ulo�en�. Ak sa ��slo v strome nenach�dza, tak ho najprv pridajte do stromu.

�pecifik�cia vstupu: Na vstupe je nieko�ko ��sel, ktor� postupne vklad�te do stromu. ��sla s� oddelen� medzerou alebo nov�m riadkom.

�pecifik�cia v�stupu: Pre ka�d� ��slo na vstupe vyp�te jedno ��slo -- ako hlboko je dan� ��slo ulo�en� v strome.

Uk�ka vstupu:
5
3
2
1
3
V�stup pre uk�kov� vstup:
0
1
2
3
1
*/
#include <stdio.h>
#include <stdlib.h>

struct tree {
  struct point *root;
};

struct point {
  int value;
  struct point *left, *right;
};

int main()
{
  struct tree *s = malloc(sizeof(struct tree));
  s->root = NULL;

  int cislo, depth;

  while(scanf("%d", &cislo) > 0) {
    depth = 0;

    if (s->root == NULL) {
    	s->root = malloc(sizeof(struct point));
    	s->root->value = cislo;
    	s->root->left = NULL;
    	s->root->right = NULL;
      printf("%d\n", depth);
    }
  	else {
    	struct point *act = malloc(sizeof(struct point));
    	act = s->root;

    	while (1) {
        	if (act->value == cislo) {
            	printf("%d\n", depth);
            	break;
            }
            else if (act->value > cislo) {
            	if (act->right == NULL) {
            		act->right = malloc(sizeof(struct point));
              		act->right->value = cislo;
              		printf("%d\n", ++depth);
              		break;
            	}
            	else {
              		act = act->right;
              		depth++;
            	}
            }
          	else {
                if (act->left == NULL) {
              		act->left = malloc(sizeof(struct point));
              		act->left->value = cislo;
              		printf("%d\n", ++depth);
              		break;
            	}
            	else {
              		act = act->left;
              		depth++;
            	}
          	}
        }
  	}
  }
  return 0;
}
