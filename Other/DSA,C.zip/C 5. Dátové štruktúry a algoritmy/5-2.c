/*
Ur�ite ste to u� za�ili... ve�er, diskot�ka, pri vchode sympatick� vyhadzova�i nekompromisne odmietaj� vstup neplnolet�m ml�de�n�kom, ktor� sa u� nedo�kavo tla�ia na parket. Mlad� ale vedia by� vynaliezav�, zaobstarali si ob�iansky preukaz so �spr�vnym� d�tumom narodenia a po prekonan� poslednej prek�ky si ho poza chrb�t posun� spa� a na vstupe je op� pou�it� �al��m nedo�kavcom. Takto to ale nem��e �s� �alej!! Pom��te ochr�ni� zdrav� mor�lny v�vin na�ej ml�de�e a pom��te vyhadzova�om identifikova� preukazy, ktor� boli na vstup u� raz pou�it�.

Na vstupe je dan� postupnos� ��sel ob�ianskych preukazov, v porad� ako sa nimi n�v�tevn�ci preukazuj�. Va�ou �lohou je zisti� po�et, ko�ko z nich sa pok��ali pou�i� opakovane. ��slo OP je re�azec ��sel a p�smen, m��u by� r�zne dlh�. Rie�enie mus� pracova� v optim�lnej o�ak�vanej �asovej zlo�itosti O(N), kde N je po�et ��sel ob�ianskych preukazov na vstupe.

Naprogramujte funkciu v nasledovnom tvare:

// spracuje cisla OP: vrati pocet najdenych duplikatov.
int vyhadzovac(char *a[], int n)
{
  // ...
}
Pozn�mka: V�etky potrebn� oper�cie by ste mali implementova� vlastn�mi silami. Pomal�ie ako optim�lne line�rne rie�enie nespln� �asov� limit v testova�i.
*/

// uloha-5-2.c -- Tyzden 5 - Uloha 2
// Peter Markus, 17.10.2016 11:05:01

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// spracuje cisla OP: vrati pocet najdenych duplikatov.
int vyhadzovac(char *a[], int n) //pole OP, pocet OP
{
  int i, j, dlzka, pocet = 2*n+1, duplikat = 0;
  long long cislo;
  char **pole = malloc(pocet * sizeof(char*));

  for(i = 0; i < n; i++) {  	// konverzia kodu na int a pomocne pole char
    cislo = 0;
    char pom[250];
    dlzka = strlen(a[i]);
    for(j = 0; j < dlzka; j++) {
      cislo = 13*cislo + a[i][j];			// cislo kodu
      pom[j] = a[i][j];						// chary kodu
    }
    pom[dlzka] = 0;
    cislo %= pocet;							// cislo == index v poli

    while(1) {

      if(pole[cislo] == NULL) {		// ak tam nieje, pridame
        pole[cislo] = malloc(dlzka * sizeof(char));
		strcpy(pole[cislo], pom);
        break;
      }
      else {
        if(!strcmp(pole[cislo], pom)) {
          duplikat++;
          break;
        }
        else {
          cislo++;
          if(cislo >= pocet)		// posunutie na zaciatok pola pri konci pola
        	cislo = 0;
    	}
      }
    }
  }
  return duplikat;
}

// ukazkovy test
int main(void)
{
  char *a[] = {"AA123456", "BA987689", "AA123123", "AA312312", "BB345345", "AA123123"};
  printf("Pocet duplikatov: %d\n", vyhadzovac(a, 6));
  return 0;
}
