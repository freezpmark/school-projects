/*
Nap�te program, ktor� posunie re�azec o N znakov do�ava. Posun�� nejak� re�azec o jeden znak do�ava znamen� prv� znak presun�� na koniec, pri�om druh� a ostatn� znaky sa posun� o jedno miesto do�ava, ��m na konci uvo�nia miesto pre prv� znak.

�tandardn� vstup obsahuje nieko�ko riadkov, na ka�dom z nich je uveden� re�azec (najviac 1000 znakov) a prirodzen� ��slo N (najviac sto mili�rd). Pre ka�d� riadok na vstupe vyp�te na �tandardn� v�stup re�azec posunut� o N znakov do�ava.

Pozn�mka: Va�e rie�enie mus� by� dostato�ne efekt�vne, aby zbehlo v �asovom limite.
Uk�ka vstupu:
abeceda 3
aaaaabaaa 2
V�stup pre uk�kov� vstup:
cedaabe
aaabaaaaa
*/


// uloha-1-1.c -- Tyzden 1 - Uloha 1
// Peter Markus, 21.9.2016 14:01:07

#include <stdio.h>
#include <string.h>

int main()
{
    char word[1000];
    int i, length;
    unsigned long skip;

    while(scanf("%s %lu", word, &skip) == 2) {
        length = strlen(word);
        skip = skip % length;

        for(i = 0; ; i++)
            if(word[skip+i] == '\0')
                break;
            else
                printf("%c", word[skip+i]);

        for(i = 0; i < skip; i++)
            printf("%c", word[i]);
        printf("\n");
    }
    return 0;
}
