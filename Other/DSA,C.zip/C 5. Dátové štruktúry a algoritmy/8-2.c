/*
Jakubko prech�dza cez les trasou, ktor� ste mu vyzna�ili ... len�e v h��tin�ch sa nie�o h�be... Jakubko v�era vyna�iel pr�stroj na extrakciu bubliniek z hydrof�bnych roztokov a m� preto d�vodn� podozrenie, �e ho pri�li nav�t�vi� kamar�ti z inej galaxie, ob�va sa �nosu. Pom��te mu strategicky analyzova� les, a objavi� v �om kritick� body, cez ktor� mus� nutne prejs� bez oh�adu na trasu prechodu, ktor� si zvol�. Na t�chto miestach chce by� Jakubko obzvl᚝ obozretn�. Tmav� les je tvaru dvojrozmernej mrie�ky, Jakubko vst�pil do lesa v�avo hore, a potrebuje sa dosta� do v�chodu vpravo dole. In� v�chody z lesa nie s�, v lese sa pohybuj� mimozem��ania, ktor� sa pok��aj� Jakubka kontaktova�, on nem� z�ujem o tak�to soci�lne kontakty.

Pom��te Jakubkovi n�js� v�etky kritick� pol��ka (lesn� cesti�ky) cez ktor� mus� nutne prejs� bez oh�adu na zvolen� trasu.

Vstup: �tandardn� vstup obsahuje mapu lesa -- dvojrozmern� maticu znakov bodka (.) a mrie�ka (#). Bodka predstavuje lesn� cesti�ku. Mrie�ka predstavuje h��tinu, cez ktor� sa Jakubko nem��e dosta�. Mapa lesa m��e by� ve�k� najviac 1000 riadkov a 1000 st�pcov.

V�stup: Na �tandardn� v�stup vyp�te mapu lesa s vyzna�en�mi kritick�mi miestami -- pol��kami cez ktor� mus� nutne prejs� bez oh�adu na zvolen� trasu prechodu z �av�ho horn�ho vchodu do prav�ho doln�ho v�chodu. Kritick� miesta ozna�te v�kri�n�kom (znak !).

Uk�ka vstupu:
#.###############
#...#...........#
#.###.#####.#.#.#
#...........#...#
###############.#
V�stup pre uk�kov� vstup:
#!###############
#!..#......!!!..#
#!###.#####.#.#.#
#!!!!!......#..!#
###############!#
*/


// uloha-8-2.c -- Tyzden 8 - Uloha 2
// Peter Markus, 8.11.2016 13:55:56

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char mapa[1000][1000];
char mapa2[1000][1000];

void mapaDisplay(int b, int a)
{
	int i;
	for (i = 0; i < b; i++ )
		printf("%.*s\n", a, mapa[i]);
	printf("\n");
}

int leftPath(int x, int y, int a, int b)
{
	if (x < 0 || x > a || y < 0 || y > b)
        return 0;

  	if (mapa[y][x] == '.' && ( y == b && x == a)) {
    	mapa[y][x] = '*';
    	return 1;
    }

  	if (mapa[y][x] != '.')
    	return 0;

	mapa[y][x] = '*';
	if (leftPath(x - 1, y, a, b) == 1)
        return 1;

	if (leftPath(x, y - 1, a, b) == 1)
        return 1;

  	if (leftPath(x + 1, y, a, b) == 1)
        return 1;

	if (leftPath(x, y + 1, a, b) == 1)
        return 1;

	mapa[y][x] = '.';

	return 0;
}

int rightPath(int x, int y, int a, int b)
{
	if (x < 0 || x > a || y < 0 || y > b)
        return 0;

  	if (mapa2[y][x] == '.'  && (y == b && x == a)) {
    	mapa2[y][x] = '*';
    	return 1;
    }

  	if (mapa2[y][x] != '.' )
    	return 0;

	mapa2[y][x] = '*';

	if (rightPath(x, y + 1, a, b) == 1)
        return 1;
	if (rightPath(x + 1, y, a, b) == 1)
        return 1;
	if (rightPath(x - 1, y, a, b) == 1)
        return 1;
	if (rightPath(x, y - 1, a, b) == 1)
        return 1;

	mapa2[y][x] = '.';

	return 0;
}

void compareLC(int a, int b) {

	int i, j;

  	for(i = 0; i < a; i++) {
      	for(j = 0; j < b; j++) {
      		if(mapa[i][j] == mapa2[i][j]) {
          		if(mapa[i][j] == '#')
      				mapa[i][j] = '#';
          		else if(mapa[i][j] == '*')
            		mapa[i][j] = '!';
        	}
        	else
         		mapa[i][j] = '.';
	  	}
  	}
}

int main()
{
  	int i = 0, j = 0, k = 0, x = 0, y = 0, imax = 0, line, column;

  	while(scanf("%s", mapa[i]) > 0) {
    	for(j = 0; mapa[i][j] != '\0'; j++)
      		k++;

    	if (k > imax)
      		imax = k;
    	k = 0;
    	i++;
  	}

  	column = imax;
  	line = i;
  	x = column - 2;
  	y = line - 1;
  	i = 0;

  	for(i = 0; i < line; i++)
    	for(j = 0; j < column; j++)
        	mapa2[i][j] = mapa[i][j];

  	rightPath(1, 0, x, y);
  	leftPath(1, 0, x, y);

  	compareLC(line, column);
  	mapaDisplay(line, column);

  	return 0;
}
