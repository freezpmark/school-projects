/*
Dan� dve mno�iny S a T prirodzen�ch ��sel, ich prvky s� s1, s2, ..., sN, a t1, t2, ..., tM. Zistite, �i je S podmno�inou T, teda, �i ka�d� prvok mno�iny S je aj prvkom mno�iny T. Rie�enie mus� pracova� v optim�lnej o�ak�vanej �asovej zlo�itosti O(N+M).

Naprogramujte funkciu v nasledovnom tvare:

// vrati 1 ak 's' je podmnozina 't', inak vrati 0.
int is_subset(int s[], int n, int t[], int m)
{
  // ...
}
N�vod: Pou�ite hashovaciu tabu�ku.

Do tabu�ky najsk�r vlo�te prvky mno�iny T.
N�sledne, v tabu�ke vyh�adajte prvky mno�iny S.
Pozn�mka: V�etky potrebn� oper�cie by ste mali implementova� vlastn�mi silami. Pomal�ie ako optim�lne line�rne rie�enie nespln� �asov� limit v testova�i.
*/

// uloha-5-1.c -- Tyzden 5 - Uloha 1
// Peter Markus, 17.10.2016 11:03:35

#include <stdio.h>
#include <stdlib.h>

// vracia poziciu prvku v hashovacej tabulke
// alebo miesto, do ktoreho sa ulozi
int search(int *hash, int prvok, int size)
{
	int i = 1, pos = prvok % size;

	while (hash[pos] != 0 && hash[pos] != prvok)
		pos = (pos + i++) % size;
	return pos;
}

// vrati 1 ak 's' je podmnozina 't', inak vrati 0.
int is_subset(int s[], int n, int t[], int m)
{
	int i, j, size = 2*m + 1;

	do {    //urcenie najvacsieho a najblizsieho prvocisla
		j = 0;
		size += 2;
		for (i = 3; i*i <= size; i+=2)
			if (size % i == 0) {
				j = 1;
				break;
			}
	} while(j > 0);

	// alokovanie hash tabulky s nulovymi hodnotami
	int *hash = (int *)malloc(sizeof(int) * size);
	for (i = 0; i < size; i++)
		hash[i] = 0;

    //ulozenie prvkov do tabulky
	for (j = 0; j < m; j++) {
		i = search(hash, t[j], size);
     	hash[i] = t[j];
	}

	//vyhladavanie prvku
	for (j = 0; j < n; j++) {
		i = search(hash, s[j], size);
		if (hash[i] != s[j])
			return 0;
	}
	return 1;
}

// ukazkovy test
int main(void)
{
  int a[] = {10, 20, 30};
  int b[] = {30, 10};
	if (is_subset(b, 2, a, 3))
    printf("B je podmnozina A (spravne)\n");
   else
    printf("B nie je podmnozina A (nespravne)\n");
  return 0;
}
