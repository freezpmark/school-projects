/*
Jakubko za�al podnika�. Priebe�ne mu chodia objedn�vky, ale nest�ha v�etky vybavova�, tak si mus� vybra�, ktor�ch z�kazn�kov obsl��i. Jednotliv� objedn�vky si ohodnot� hodnotou, ak� maj� pre jeho podnikanie. Z �asu na �as, ke� m� �as, vybav� jednu objedn�vku, v tomto momente sa pozrie do svojho zoznamu a vyberie objedn�vky s najvy��iu hodnotu a spracuje ju. Pom�te Jakubkovi a spravte mu program, ktor� mu pom�e oper�cie vlo�enia a v�beru objedn�vky s najvy��ou prioritou r�chlo vykon�va�.

Naprogramujte funkcie v nasledovnom tvare:

// vlozi meno a hodnotu do prioritnej fronty
void vloz(char *meno, int hodnota)
{
	// ...
}

/// vrati meno, ktore je v prioritnej fronte s najvyssou hodnotou a odstrani ho z prioritnej fronty
char *vyber_najvyssie()
{
	// ...
}
Prioritn� frontu implementujte bin�rnou haldou. Pou�ite glob�lnu premenn�. M�ete predpoklada�, �e Jakubko bude ma� v �ubovo�nom okamihu najviac 100 000 �akaj�cich objedn�vok.
*/

// uloha-4-2.c -- Tyzden 4 - Uloha 2
// Peter Markus, 10.10.2016 16:13:01

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define PARENT(i) (i/2)
#define LEFT(i) (2*i)
#define RIGHT(i) (2*i+1)

typedef struct node{
    int data;
    char name[100];
} NODE;

    NODE *hp[110000];
    int large = 0;
    int size = 0;
    int i = 0;

void heapify(NODE *hp[100001], int i)
{
    NODE *tmp = NULL;
    if(LEFT(i) <= size && hp[LEFT(i)]->data > hp[i]->data)
        large = LEFT(i);
    else
        large = i;
        
    if(RIGHT(i) <= size && hp[RIGHT(i)]->data > hp[large]->data)
        large = RIGHT(i);
    if(large != i){
        tmp = hp[i];
        hp[i] = hp[large];
        hp[large] = tmp;
        heapify(hp, large);
    }
}

void vloz(char *name, int cash)
{
    size++;
    int act = size;
 	NODE *tmp = NULL;
 	NODE *h = NULL;
  	h = (NODE *)malloc(sizeof(NODE));

  	strcpy(h->name, name);
  	h->data = cash;
  	hp[size] = h;

    while(act > 1 && hp[PARENT(act)]->data < hp[act]->data){
      	tmp = hp[act];
      	hp[act] = hp[PARENT(act)];
      	act = PARENT(act);
      	hp[act] = tmp;
    }
}


char *vyber_najvyssie()
{
    NODE *max = NULL;

    if (size > 0) {
        max = hp[1];
        hp[1] = hp[size];
        heapify(hp,1);
        size--;
    }
  	return max->name;
}

int main()
{
  char buf[100];
  int x;

  while (scanf("%s", buf) > 0)
  {
    if (!strcmp(buf, "vyber"))
      printf("%s\n", vyber_najvyssie());
    else
    {
      scanf("%s %d", buf, &x);
      vloz(buf, x);
    }
  }

  return 0;
}

