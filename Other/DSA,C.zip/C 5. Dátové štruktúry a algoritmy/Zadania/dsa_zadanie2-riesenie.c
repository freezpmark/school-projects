#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#define hash_prime 12289


#include <sys/time.h>
#include <stdint.h>
#if (_POSIX_C_SOURCE+0) < 199309L // Do we have nanosleep?
#    if defined(_WIN32) || defined(_WIN64) // Do we have Windows?
#        include <windows.h>
         struct timespec {
             long tv_sec; int_least32_t tv_nsec;
         };
#        define nanosleep(a, b) \
              (Sleep((a)->tv_sec*1000 + (a)->tv_nsec/1000000L), \
               (b)->tv_sec = (b)->tv_nsec = 0, 0)
#    else
#        error "unrecognized target platform"
#    endif
#endif


typedef struct node {
    struct node *right;
	struct node *left;
	char *userName;
	int height;
	int likes;
} NODE;

typedef struct page {
	struct page *next;
	struct node *root;
	char *pageName;
} PAGE;

PAGE **hashTable;

int hash(char *str) // djb2
{
	unsigned long hash = 5381, mod = 0;
	int c;
	while((c = *str++))
        hash = ((hash << 5) + hash) + c;
    mod = hash % hash_prime;

    return (int) mod;
}


int getMax(int left, int right) {
	return (left > right) ? left : right;
}


int getHeight(NODE *node) {
    return (node != NULL) ? node->height : 0;
}


int getBalance(NODE *node) {
    return (node != NULL) ? getHeight(node->left) - getHeight(node->right) : 0;
}


NODE *newNode(char *user)
{
	NODE *node       = malloc(sizeof(NODE));
	node->userName   = strdup(user);
	node->left  = node->right  = NULL;
	node->likes = node->height = 1;

	return node;
}


int getLikes(NODE *node)
{
	if(node == NULL)
		return 0;

    int likes = 1;
    likes += (node->right != NULL) ? node->right->likes : 0;
    likes += (node->left  != NULL) ? node->left->likes  : 0;

	return likes;
}


NODE *getUserName(NODE *node, int kth)
{
	int likes = getLikes(node->left);

	if(kth > likes)
		return getUserName(node->right, kth - (likes + 1));
    if(kth < likes)
        return getUserName(node->left, kth);

    return node;
}


NODE *rightRotate(NODE *y)
{
	NODE *x = y->left;
	NODE *T = x->right;

	x->right = y;
	y->left = T;

	y->height = getMax(getHeight(y->left), getHeight(y->right)) + 1;
    x->height = getMax(getHeight(x->left), getHeight(x->right)) + 1;

    y->likes = getLikes(y);
    x->likes = getLikes(x);

    return x;
}


NODE *leftRotate(NODE *x)
{
	NODE *y = x->right;
	NODE *T = y->left;

	y->left = x;
	x->right = T;

	x->height = getMax(getHeight(x->left), getHeight(x->right)) + 1;
    y->height = getMax(getHeight(y->left), getHeight(y->right)) + 1;

    x->likes = getLikes(x);
    y->likes = getLikes(y);

    return y;
}


NODE *deleteNode(NODE* node, char *user)
{
	if(node == NULL)
		return node;

	if(strcmp(node->userName, user) > 0)
		node->left = deleteNode(node->left, user);

	else if(strcmp(node->userName, user) < 0)
		node->right = deleteNode(node->right, user);

	else {  // (user == node->userName)
		if(node->left != NULL && node->right != NULL) {
        	NODE *tmp = node->right;
            while(tmp->left != NULL)
				tmp = tmp->left;
			node->userName = strdup(tmp->userName);
			node->right = deleteNode(node->right, tmp->userName);
			// presun najlavejsieho uzla k aktualnemu
        }
        else {
            NODE *tmp = (node->left)  ? node->left : node->right;
                 node = (tmp == NULL) ? NULL       : tmp;
            // ak iba lavy/pravy uzol existuje, ulozi sa do aktualneho
            // ak lavy aj pravy uzol je prazdny, tak ho mozeme vymazat
        }
	}
	if(node == NULL)
		return node;

    int balance = getBalance(node);
    node->likes = getLikes(node);
    node->height = getMax(getHeight(node->left), getHeight(node->right)) + 1;

    if(balance > 1 && getBalance(node->left) > 0)
        return rightRotate(node);

    if(balance < -1 && getBalance(node->right) < 0)
        return leftRotate(node);

    if(balance > 1 && getBalance(node->left) < 0){
        node->left = leftRotate(node->left);
        return rightRotate(node);
    }

    if(balance < -1 && getBalance(node->right) > 0){
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }

    return node;
}


NODE *insert(NODE *node, char *user)
{
    if (node == NULL)
        return(newNode(user));

    if(strcmp(user, node->userName) > 0)
        node->right = insert(node->right, user);
    else
      	node->left = insert(node->left, user);

    int balance = getBalance(node);
    node->likes = getLikes(node);
    node->height = getMax(getHeight(node->left), getHeight(node->right)) + 1;

    if(balance > 1 && strcmp(user, node->left->userName) < 0)
        return rightRotate(node);   // Left Left pripad

    if(balance < -1 && strcmp(user, node->right->userName) > 0)
        return leftRotate(node);    // Right Right

    if(balance > 1 && strcmp(user, node->left->userName) > 0) {
        node->left = leftRotate(node->left);
        return rightRotate(node);   // Left Right
    }

    if(balance < -1 && strcmp(user, node->right->userName) < 0) {
        node->right = rightRotate(node->right);
        return leftRotate(node);    // Right Left
    }

    return node;
}



void init()
{
	hashTable = calloc(hash_prime, sizeof(PAGE));
}


void like(char *strPage, char *user)
{
	int a = hash(strPage);

	if (hashTable[a] == NULL){
    	hashTable[a]            = malloc(sizeof(PAGE));
        hashTable[a]->pageName  = strdup(strPage);
        hashTable[a]->next      = NULL;
        hashTable[a]->root      = NULL;
        hashTable[a]->root      = insert(hashTable[a]->root, user);
	}
	else {  // vyhladanie alebo vytvorenie stranky uz v spajanom zozname
    	PAGE *page = hashTable[a];
		while(page->next != 0 && strcmp(page->pageName, strPage) != 0)
        	page = page->next;

		if(strcmp(page->pageName, strPage) == 0)
          page->root = insert(page->root, user);
        else {
        	page->next           = malloc(sizeof(PAGE));
        	page->next->pageName = strdup(strPage);
	    	page->next->next     = NULL;
	    	page->next->root     = NULL;
			page->next->root     = insert(page->next->root, user);
		}
  	}
}


void unlike(char *strPage, char *user)
{
	PAGE *page = hashTable[hash(strPage)];
	while(page != NULL && (strcmp(page->pageName, strPage) != 0))
		page = page->next;

	page->root = deleteNode(page->root, user);
}


char *getuser(char *strPage, int k)
{
	PAGE *page = hashTable[hash(strPage)];
    while(page != NULL && strcmp(page->pageName, strPage) != 0)
        page = page->next;

    if(strcmp(page->pageName, strPage) != 0)
        page = NULL;

	if(--k < getLikes(page->root)) {
        NODE *node = getUserName(page->root, k);
        return node->userName;
	}

    return NULL;
}


/*
struct timeval GetTimeStamp() {
    struct timeval tv;
    gettimeofday(&tv,NULL);
    return tv;
}*/

double time_diff(struct timeval x , struct timeval y)
{
    double x_ms, y_ms, diff;

    x_ms = (double)x.tv_sec * 1000000 + (double)x.tv_usec;
    y_ms = (double)y.tv_sec * 1000000 + (double)y.tv_usec;

    diff = (double)y_ms - (double)x_ms;
    return diff;
}


int main()
{
    int i, pocet = 1000100;
    char name[35];
    int diff;
    init();

    clock_t        t1, t2, t3, t4, t5, t6, t7, t8, t9, t10;
    struct timeval b1, b2, b3, b4, b5;
    struct timeval a1, a2, a3, a4, a5;

    FILE *fr;
    fr = fopen("gen.txt", "r");
    printf("Lajkovanie v neusporiadanom subore\n\n");
    for(i = 0; i < pocet; i++) {
        fscanf(fr, "%s", name);
        like("fanpage", name);
        if(i == 0) {
            t1 = clock();
            gettimeofday(&b1 , NULL);
        }
        if(i == 100) {
            printf("Pocet lajkov: 100\n");
            t2 = clock();
            diff = (t2 - t1) ;
            printf("Milliseconds: %d ms\n", diff);
            gettimeofday(&a1 , NULL);
            printf("Microseconds: %.0lf us\n" , (time_diff(b1 , a1)) );
        }

        if(i == 0) {
            t3 = clock();
            gettimeofday(&b2 , NULL);
        }
        if(i == 1000) {
            printf("\nPocet lajkov: 1 000\n");
            t4 = clock();
            diff = (t4 - t3) ;
            printf("Milliseconds: %d ms\n", diff);
            gettimeofday(&a2 , NULL);
            printf("Microseconds: %.0lf us\n" , (time_diff(b2 , a2)) );
        }
        if(i == 0) {
            t5 = clock();
            gettimeofday(&b3 , NULL);
        }
        if(i == 10000) {
            printf("\nPocet lajkov: 10 000\n");
            t6 = clock();
            diff = (t6 - t5) ;
            printf("Milliseconds: %d ms\n", diff);
            gettimeofday(&a3 , NULL);
            printf("Microseconds: %.0lf us\n" , (time_diff(b3 , a3)) );
        }
        if(i == 0) {
            t7 = clock();
            gettimeofday(&b4 , NULL);
        }
        if(i == 100000) {
            printf("\nPocet lajkov: 100 000\n");
            t8 = clock();
            diff = (t8 - t7) ;
            printf("Milliseconds: %d ms\n", diff);
            gettimeofday(&a4 , NULL);
            printf("Microseconds: %.0lf us\n" , (time_diff(b4 , a4)) );
        }
        if(i == 0) {
            t9 = clock();
            gettimeofday(&b5 , NULL);
        }
        if(i == 1000000) {
            printf("\nPocet lajkov: 1 000 000\n");
            t10 = clock();
            diff = (t10 - t9) ;
            printf("Milliseconds: %d ms\n", diff);
            gettimeofday(&a5 , NULL);
            printf("Microseconds: %.0lf us\n" , (time_diff(b5 , a5)) );
        }
    }




    init();

    clock_t        tt1, tt2, tt3, tt4, tt5, tt6, tt7, tt8, tt9, tt10;
    struct timeval bb1, bb2, bb3, bb4, bb5;
    struct timeval aa1, aa2, aa3, aa4, aa5;

    FILE *frr;
    frr = fopen("uspgen.txt", "r");
    printf("\n\nLajkovanie v usporiadanom subore\n\n");
    for(i = 0; i < pocet; i++) {
        fscanf(frr, "%s", name);
        like("fanpage", name);
        if(i == 0) {
            tt1 = clock();
            gettimeofday(&bb1 , NULL);
        }
        if(i == 100) {
            printf("Pocet lajkov: 100\n");
            tt2 = clock();
            diff = (tt2 - tt1) ;
            printf("Milliseconds: %d ms\n", diff);
            gettimeofday(&aa1 , NULL);
            printf("Microseconds: %.0lf us\n" , (time_diff(bb1 , aa1)) );
        }

        if(i == 0) {
            tt3 = clock();
            gettimeofday(&bb2 , NULL);
        }
        if(i == 1000) {
            printf("\nPocet lajkov: 1 000\n");
            tt4 = clock();
            diff = (tt4 - tt3) ;
            printf("Milliseconds: %d ms\n", diff);
            gettimeofday(&aa2 , NULL);
            printf("Microseconds: %.0lf us\n" , (time_diff(bb2 , aa2)) );
        }
        if(i == 0) {
            tt5 = clock();
            gettimeofday(&bb3 , NULL);
        }
        if(i == 10000) {
            printf("\nPocet lajkov: 10 000\n");
            tt6 = clock();
            diff = (tt6 - tt5) ;
            printf("Milliseconds: %d ms\n", diff);
            gettimeofday(&aa3 , NULL);
            printf("Microseconds: %.0lf us\n" , (time_diff(bb3 , aa3)) );
        }
        if(i == 0) {
            tt7 = clock();
            gettimeofday(&bb4 , NULL);
        }
        if(i == 100000) {
            printf("\nPocet lajkov: 100 000\n");
            tt8 = clock();
            diff = (tt8 - tt7) ;
            printf("Milliseconds: %d ms\n", diff);
            gettimeofday(&aa4 , NULL);
            printf("Microseconds: %.0lf us\n" , (time_diff(bb4 , aa4)) );
        }
        if(i == 0) {
            tt9 = clock();
            gettimeofday(&bb5 , NULL);
        }
        if(i == 1000000) {
            printf("\nPocet lajkov: 1 000 000\n");
            tt10 = clock();
            diff = (tt10 - tt9) ;
            printf("Milliseconds: %d ms\n", diff);
            gettimeofday(&aa5 , NULL);
            printf("Microseconds: %.0lf us\n" , (time_diff(bb5 , aa5)) );
        }
    }
    return 0;
}


  /*  struct timeval before , after;
    gettimeofday(&before , NULL);
    //Time taking task
    for (i=1 ; i <= 100 ; i++)
        printf("%d %d %d n",i, i*i, i*i*i);
    gettimeofday(&after , NULL);
    printf("Total time elapsed : %.0lf us" , time_diff(before , after) );
*/



    /*
    int j;
    int dlzka=1000100;
    FILE *fw;
    fw=fopen("gen.txt","w");
    srand(time(NULL));

    for(i=0;i<dlzka;++i){
        for(j=0;j<30;++j){
            if(rand()%2==0)
                name[j]=((rand()%('z'-'a'))+'a');
            else {
                if(rand()%2==1)
                     name[j]=(rand()%('z'-'a')+'A');
                else
                    name[j]=(rand()%('9'-'0')+'0');
            }
        }
        name[30]='\n';
        name[31]='\0';
        fprintf(fw,"%s",name);
    }
    fclose(fw);
    */
