// zadanie1.c -- Zadanie 1 - Spravca pamati
// Peter Markus, 4.10.2016 13:59:24

#include <stdio.h>
#include <stdlib.h>

typedef struct header {
    char available;
    unsigned int size;
    struct header *next;
}HEADER;

// pomocne funkcie
HEADER* findMemory(unsigned int size);
void fragMemory(HEADER** freeblock, unsigned int size);
void defragMemory(HEADER** mergeBlock);

// hlavne funkcie
void *memory_alloc(unsigned int size);
int memory_free(void *valid_ptr);
int memory_check(void *ptr);
void memory_init(void *ptr, unsigned int size);

void *gPointer;     // pointer na zaciatok vyhradenej pamate


void memory_init(void *ptr, unsigned int size)
{
    // posun o 4 bajty dopredu, lebo prve 4 bajty su urcene pre cislo velkosti celej pamate
    HEADER *first = (HEADER *)((int *) ptr + 1);

    /* pridavam adresu ptr do premennej ktora predstavuje velkost celej pamate,
       pridana velkost je odobrata hlavickou a jeho samotnym cislom velkosti  */
    unsigned int *heapSize = (unsigned int*) ptr;
    *heapSize = size - sizeof(HEADER) - sizeof(unsigned int);

    if(*heapSize <= 0) {
        //printf("Nedostatocna velkost pamate na vytvorenie blokov\n");
        return;
    }
    if(ptr == NULL) {
        //printf("Neplatny prideleny blok celkovej pamate\n");
        return;
    }

    gPointer = ptr;
    first->available = 1;
    first->size = *heapSize;
    first->next = NULL;
}


void *memory_alloc(unsigned int size)
{
    if(size == 0) {
        //printf("Nema zmysel alokovat nulovu velkost!\n");
        return NULL;
    }

    HEADER *freeBlock = (HEADER *) ((int *) gPointer + 1);
    freeBlock = findMemory(size);                            // FirstFit princip

    if (!freeBlock) {
        //printf("Nenasla sa volna pamat\n");
        return NULL;
    }

    freeBlock->available = 0;
	fragMemory(&freeBlock, size);   // rozdelenie pamate.. dava sa adresovy argument, aby sa to nemuselo vracat cez navratovu hodnotu
    return freeBlock + 1;           // posunie o 1 datovy typ HEAD, lebo chcem zacat zapisovat na adresu dat
}


int memory_check(void *ptr)
{
	if(gPointer > ptr)                  // adresa sa nachadza vlavo od adresy pamate memory_init
        return 0;

    int *pom = (int *) gPointer;
    if((gPointer + *pom) < ptr)
        return 0;

    HEADER** actual;                    // ide sa od adresy adries
	int *pom2 = (int *) gPointer + 1;
	for
    (actual = (HEADER**)&pom2;           // cez adresu adries sa pohybujeme namiesto bajtov cez adresy (HEADERY)
    *actual != NULL;                    // prehladavanie az do posledneho bloku v pamati
     actual = &(*actual)->next) {      // prechadzanie do dalsieho bloku
		if(*actual == ptr)
			return 1;
        if(*actual > ptr)
            return 0;
     }
	return 0;
}




int memory_free(void *valid_ptr)
{
	// presun valid_ptr na hlavicku, - sizeof(HEADER) zaruci aby neukazoval na hodnotu pola, ale na hlavicku
	HEADER* mergeBlock = (HEADER*) ((char*) valid_ptr - sizeof(HEADER));

	if(mergeBlock == NULL || mergeBlock->available || !memory_check(mergeBlock) ) { // zly vstup || je k dispozicii || nieje v nasej pamati
		//printf("Pointer nikam neukazuje!\n");
		return 1;
	}

	mergeBlock->available = 1;
	defragMemory(&mergeBlock);
	return 0;
}




HEADER* findMemory(unsigned int size)
{
	HEADER **actual;                    // ide sa od adresy adries

	int *pom = ((int*) gPointer + 1);
	for
    (actual = (HEADER**)&pom;           // cez adresu adries sa pohybujeme namiesto bajtov cez adresy (HEADERY)
    *actual != NULL;                    // prehladavanie az do posledneho bloku v pamati
     actual = &(*actual)->next)         // prechadzanie do dalsieho bloku
        if((*actual)->available && (*actual)->size >= size) {// blok musi byt volny a zaroven mat dostatocnu pamat
            return *actual;
        }



	return NULL;
}


void fragMemory(HEADER** freeBlock, unsigned int size)
{
	int rest = (*freeBlock)->size - size;              // zvysok volnej pamate v bloku

	// na vytvorenie dalsieho bloku potrebujeme miesto pre hlavicku a aspon jeden bajt
	if(rest >= (int)(sizeof(HEADER)+sizeof(char))) {
        // pretyp. na char(bajty) <- adresa bloku + jeho velkost + velkost vytvoreneho headeru
		HEADER* newBlock = (HEADER*) ((char*)(*freeBlock) + size + sizeof(HEADER));
		newBlock->available = 1;
		newBlock->size = rest - sizeof(HEADER);
		newBlock->next = (*freeBlock)->next;
		(*freeBlock)->size = size;
		(*freeBlock)->next = newBlock;
		return;
	}
	(*freeBlock)->size = size;
	// nic sa nestane.. freeBlock ma teda velkost taku, aku mal aj pri prvej alokacii
}


void defragMemory(HEADER** mBlock)
{
	while((*mBlock)->next != NULL && (*mBlock)->next->available == 1) {
		(*mBlock)->size += sizeof(HEADER) + (*mBlock)->next->size;
        (*mBlock)->next = (*mBlock)->next->next;
	}
}

/* TESTING FUNCTIONS */
int assertListElements(char expectedListElements[], int expectedSize, char * array);
void test_memory_init();                    //  otestuje funkciu memory_init
void test_insertFirstElement();             //  10 bajtov         (100 mem)   (maly)
void test_insertMultipleDiffSizedElements();    //  7, 50, 125, 300   (500 mem)   (male/velke, rozne, mem 500)
void test_insertNotInvalidElement();        //  ked mam pamat 100, tak neprejde alokovanie 100 bajtov
void test_freeFirstElement();               //  uvolnit nejaky blok       (jeden)
void test_freeMultipleElements();           //  uvolnit viac blokov       (viac blokov uvolnit ktore niesu zasebou)
void test_freeAndInsertElements();          //  uvolnit a pridat bloky    (uvolnenie viac blokov a pridat tam zaroven)
void test_freeAndInsertInvalidElement();    //  uvolnit a pridat vacsi    (uvolnenie blokov a neuspesne pridanie)

int assertListElements(char *expectedListElements, int expectedSize, char * array)
{
    int i;
    for(i = 0; i < expectedSize; i++)
        if(expectedListElements[i] != array[i])
            return 1;
    return 0;
}


void test_memory_init()
{
    printf("1. test: inicialization of memory\n");
    char region[1000];
    memory_init(region, 1000);
    if(region == NULL)
        printf("Unsuccessful inicialization of memory\n\n");
    else
        printf("Successful inicialization of memory\n\n");
}


void test_insertFirstElement(char *firstArray)
{
    printf("2. test: insert first element in empty list\n");
    firstArray = (char *)memory_alloc(10);
    int i;
    //printf("Printing array letters: ");
    for(i = 0; i < 4; i++) {
        firstArray[i] = 65 + i;
        //printf("%c", firstArray[i]);
    }
    //printf("\n");

	if(assertListElements(((char[]){'A', 'B', 'C', 'D'}), 4, firstArray))
        printf("Unsuccessful insertion of first element in empty list\n\n");
    else
        printf("Successful insertion of first element in empty list\n\n");

}


void test_insertMultipleDiffSizedElements(char *secondArray, char *thirdArray)
{
    printf("3. test: insert two different elements in a list already filled with one element\n");
    secondArray = (char *)memory_alloc(14);
    int i;
    for(i = 0; i < 2; i++)
        secondArray[i] = 69 + i;
    if(assertListElements(((char[]){'E'}), 1, secondArray))
        printf("Unsuccessful insertion of second element\n");
    else
        printf("Successful insertion of second element\n");

    thirdArray = (char *)memory_alloc(176);
    char expectedArray[26];
    for(i = 0; i < 26; i++)
        thirdArray[i] = expectedArray[i] = 70 + i;
    if(assertListElements(expectedArray, 26, thirdArray))
        printf("Unsuccessful insertion of third element\n\n");
    else
        printf("Successful insertion of third element\n\n");
}


void test_insertNotInvalidElement()
{
    printf("4. test: inserting invalid element (size is the same as big as our memory)\n");
    char *forthArray = (char *)memory_alloc(800);
    if(forthArray == NULL)
        printf("Successfully not allocated invalid element\n\n");
    else
        printf("Unsuccessfully allocated invalid elemenet\n\n");
}


void test_freeFirstElement(char *firstArray)
{
    int f = memory_free(firstArray);
    if(f)
        printf("Unsuccessfully freed first element\n\n");
    else
        printf("Successfully freed first element\n\n");
}


int main()
{
    char *firstArray, *secondArray, *thirdArray, *forthArray;
    test_memory_init();
    test_insertFirstElement(firstArray);
    test_insertMultipleDiffSizedElements(secondArray, thirdArray);
    test_insertNotInvalidElement(forthArray);

 //  test_freeFirstElement(firstArray);
 /*   test_freeMultipleElements();            uvolnit viac blokov       (viac blokov uvolnit ktore niesu zasebou)
    test_freeAndInsertElements();             uvolnit a pridat bloky    (uvolnenie viac blokov a pridat tam zaroven)
    test_freeAndInsertInvalidElement();       uvolnit a pridat vacsi    (uvolnenie blokov a neuspesne pridanie)
*/
    return 0;
}
