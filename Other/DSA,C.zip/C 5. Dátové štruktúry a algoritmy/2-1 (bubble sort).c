/*
Jakubko sa r�d hr� a potrebuje st�le nov� hra�ky. V hra�k�rstve si v�imol, �e drah�ie hra�ky s� zvy�ajne komplikovanej�ie a preto sa mu viac p��ia. Chcel by zisti�, �i maj� rodi�ia dos� pe�az� na n�kup K najdrah��ch hra�iek v obchode. Pom��te Jakubkovi zisti� ko�ko pe�az� by potreboval.

Va�ou �lohou je nap�sa� funkciu, ktor� ako vstupn� argument dostane pole cien hra�iek v obchode, ich po�et N, a ��slo K -- ko�ko hra�iek si chce Jakubko z obchodu k�pi�, a vypo��ta s��et cien K najdrah��ch hra�iek v obchode.

Naprogramujte funkciu v nasledovnom tvare:

// urci sucet k najvacsich cisel z cisel cena[0],...,cena[n-1]
long sucet_k_najvacsich(int cena[], int n, int k)
{
}
Pr�klad postupnosti:
N = 6, K = 4
10 9 8 1 2 3
V�sledok (10+9+8+3):
30
Pozn�mka: Algoritmus, ktor� usporiada ceny �tandardn�m algoritmom v �ase O(n log n) je pomal�. Rie�enie mus� be�a� v �ase O(n + k).
*/
#include <stdio.h>
#include <stdlib.h>


// urci sucet k najvacsich cisel z cisel cena[0],...,cena[n-1]
long sucet_k_najvacsich(int cena[], int n, int k)
{
    int i, j, buff;
    for(i = 1; i < n; i++) {
        for(j = i; j >= 0; j--)
            if(cena[j-1] < cena[j]) {
                buff = cena[j-1];
                cena[j-1] = cena[j];
                cena[j] = buff;
            }
            else
                break;
    }

    for(i = 0, j = 0; i < k; i++) // uz je to usporiadane, mozme scitovat
        j += cena[i];
    return j;
}

int main(void)
{
  // tu si mozete nieco testovat
  int i, *x, n, k;

  scanf("%d %d", &n, &k);
  x = (int*)malloc(n * sizeof(int));
  for (i = 0; i < n; i++)
    scanf("%d", &x[i]);

  printf("%ld\n", sucet_k_najvacsich(x, n, k));
  return 0;
}
