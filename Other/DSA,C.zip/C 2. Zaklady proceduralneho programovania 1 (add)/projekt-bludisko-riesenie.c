/*
Nakreslite bludisko N x N. (10 <= N <= 100)

Bludisko sa sklad� zo znakov # (stena) a . (chodba).

Pre N od 10 do 100 by to malo vykreslit platn� bludisko, c�m lep�ie t�m bude viac bodov.

Na zaciatku zdrojov�ho k�du v koment�ri op�te v� pr�stup (ako bludisko kresl�te)

Vela �spechov!
*/


// projekt.c -- Projekt -- Bludisko
// Peter Markus, 28.11.2015 14:51:27

#include <stdio.h>

/*
Najprv som rozmyslal ci do ifu dat stenu alebo bodku, no nakoniec som sa rozhodol
zacat stenou a potom aj bodkou. Musel som tak zacat s dvojrozmernym polom pomocou
ktoreho si budem zapisovat a prepisovat znaky zo stien na bodku.
Steny som spravil tak aby vyhoveli parnemu a neparnemu N, nasledne som pridal "stvorcove"
steny v ktorych som pridal dalsie steny pomocou funkcie modulo.
Dalej som zacal pridavat cesty pomocou sikmych/rovnych ciar ktore vedu k cielu.
Aby riesenie nebolo pri prvom pohlade zjavne, pouzil som random cisla, ktore
vytvarali dalsie matuce cesty, pripadne tvorili mnozstvo alternativnych ciest k cielu.
*/

// poznamka: Bludiska ktore maju N do 40 su lahke

int main()
{
  printf("Bludisko ma hore vlavo vchod, a vychod je vpravo dole.\n\n");
  int i, j, ran, N;
  scanf("%d", &N);
  char pole[N][N];
  for(i = 0; i < N; i++) {
    for(j = 0; j < N; j++) {
      if(
        (j == 0) || ((i == 0) && (j != 1)) || (j == N-1) || ((i == N-1) && (j != N-2)) || // vykreslenie obvodu
        ((N % 2 == 1) && ((i % 4 == 0) && ((i > 0) && (i < N-1)))) ||	// pre neparne N mriezky
        ((N % 2 == 0) && ((i % 4 == 0) && ((i > 0) && (i < N-2)))) ||  // pre parne N mriezky
        ((N % 2 == 1) && ((j % 4 == 0) && ((j > 0) && (j < N-1)) && ((i != N/4) || (j > N/(N/2))))) ||
        ((N % 2 == 0) && ((j % 4 == 0) && ((j > 0) && (j < N-2)))) ||
        ((i % 2 == 0) && (j % 3 == 0)) ||
        ((i % 2 == 0) && (j % 2 == 0))
        )
		pole[i][j] = '#';
      else
        pole[i][j] = '.';
    }
  }
  for(i = 0; i < N; i++) {
    for(j = 0; j < N; j++) {
      ran = rand() % 6;
      if(
        // TRASY, ktore su viditelne bez komentaru v riadkoch 65 a 66
        ((j <= N/2) && (i == j+1) && (j != 0)) ||				// prva trasa sikma ciara
        (((j > N/15) && (i > 2)) && ((((N/2) == i+j)))) || 		// druha trasa
      	((((j > N/3) && (j < N-2)) && (((i+(N/3)) == j+2) || ((i+(N/3)) == j+5)) && (j != 0))) || // tretia
      	((i > N/6) && (i < N-(N/4)) && (j == N-2)) ||			// zvysla ciara vpravo
      	(((i > (N/2)) && (j != N-1) && (i < N-1)) && (i+j == 2*N-N/2)) ||	// piata sikma ciara
      	((i == N-3) && (j < N-2) && (j > N/3) && (j % 3 == 0)) ||			// ciara
      	((i == j-1) && (i > ((N/2)+(N/6))) && (j != N-1)) ||				// cielova sikma ciara

        // Ciel bludiska
      	((i == N-1) && (j == N-2)) || ((i == N-2) && (j == N-2)) ||

        // Random cesty
        ((ran == 1) && (j < N-2) && (i < N-2) && (i > 1) && (j > 1) &&
        	(((pole[i-1][j] == '#') && (pole[i+1][j] == '#')) ||
        	(((pole[i][j-1] == '#') && (pole[i][j+1] == '#'))))) ||
        ((((j < N-2)) && (i < N-1)) && (((i) == j+(N/2)+4) || ((i) == j+(N/2)+6)) && (j != 0))
       )
        pole[i][j] = '.';
   //   else
   //  pole[i][j] = '#';
    }
  }

    for(i = 0; i < N; i++) {
      for(j = 0; j < N; j++)
        printf("%c", pole[i][j]);
      printf("\n");
    }

  return 0;
}
