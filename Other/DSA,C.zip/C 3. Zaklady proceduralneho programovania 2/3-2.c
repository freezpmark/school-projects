#include <stdio.h>

int main()
{
  FILE *fr;
  fr = fopen("cisla.txt", "r");
  int pole[20], b = 0, max = -1, i, index = -1;
  int c;

while ((b < 20) && (fscanf(fr, "%d", &c)) != EOF) {
    pole[b] = c;

    if (pole[b] > max) {
        max = pole[b];
        index = b;
    }
        b++;
}

for (i = 0; i < b; i++)
    printf("%d ", pole[i]);
putchar('\n');
printf("\n%d %d", index, max);
fclose(fr);
return 0;
}
