#include <stdio.h>

#define N 20

int magicky(int pole[][N], int n)
{
  int i, j;
  int sucet_r, riadky[N];
  int sucet_s, stlpce[N];
  int sucet_u = 0;

  for (i = 0; i < n; i++) {
        sucet_r = 0; sucet_s = 0;
    for (j = 0; j < n; j++) {
    	sucet_r += pole[i][j];
    	sucet_s += pole[j][i];
    }

    sucet_u += pole[i][i];
  	riadky[i] = sucet_r;
    stlpce[i] = sucet_s;
  }

  for (i = 1; i < n; i++)
    if ((riadky[i] != riadky[i-1]) || (stlpce[i] != stlpce[i-1]))
      return 0;
    if (riadky[0] != sucet_u)
      return 0;
    return 1;
}

int main()
{
  int i, j, n;
  while(scanf("%d", &n) && n != 0) {
        if (n > N)
            printf("Nespravny rozmer\n");
        else {
            int s[N][N];
            for (i = 0; i < n; i++)
                for (j = 0; j < n; j++)
                    scanf("%d", &s[i][j]);

            if (magicky(s, n) == 1)
                printf("Stvorec je magicky\n");
            else
                printf("Stvorec nie je magicky\n");
        }
  }
  return 0;
}
