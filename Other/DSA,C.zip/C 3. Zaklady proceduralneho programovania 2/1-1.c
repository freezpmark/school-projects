#include <stdio.h>
#include <stdlib.h>

int main()
{
    int riadok, stlpec, N;
    char pismeno;

    while (1) {
        scanf("%d", &N);
        if ((N < 1 || N > 15) || (N % 2 == 0))
            printf("Nespravny vstup");
        else {
            for (riadok = 1; riadok <= N; riadok++) {
                for (stlpec = 1, pismeno = 'A'+N-1; stlpec <= N; stlpec++, pismeno--)
                    if (stlpec + riadok > N)
                        putchar(pismeno);
                    else
                        putchar(' ');
                for (stlpec = 1, pismeno = 'A'; stlpec <= N; stlpec++, pismeno++)
                    if (riadok >= stlpec)
                        putchar(pismeno);
                putchar('\n');
            }
        }
    }
    return 0;
}
