#include <stdio.h>
#include <stdlib.h>

int main()
{
FILE *fr, *fw;
if ((fr = fopen("list.txt", "r")) == NULL) {
    printf("Chyba pri otvarani suboru list.txt");
    return 1;
}
if ((fw = fopen("sablona.txt", "w")) == NULL) {
    printf("Nepodarilo sa otvorit sablona.txt");
    return 1;
}

int a, b = 0;

while (1) {
    a = getc(fr);
    if (((a <= '9') && (a >= '0')) || ((a >= 'A') && (a <= 'z')))
        b++;
    else {
        if ((b < 4) && (b > 0))
            fprintf(fw,"___");
        if (b >= 4)
            fprintf(fw,"_____");
      	if (a == EOF)
          	break;
        b = 0;
        putc(a, fw);
    }
}

if ((fclose(fw)) == EOF) {
    printf("Nepodarilo sa zatvorit subor");
    return 1;
}

if ((fclose(fr)) == EOF) {
    printf("Nepodarilo sa zatvorit subor");
    return 1;
}
return 0;
}
