#include <stdio.h>
#include <stdlib.h>

void zlomok(int cit, int men)
{
    int pom, max;
    if (cit > men) {
        pom = cit;
        cit = men;
        men = pom;
    }

    for (pom = 1; pom <= men; pom++)
        if ((cit % pom == 0) && (men % pom == 0))
            max = pom;
    cit /= max;
    men /= max;

    printf("Zakladny tvar zlomku: %d/%d", cit, men);
}

int main()
{
    int citatel, menovatel;
    scanf("%d %d", &citatel, &menovatel);
    zlomok(citatel, menovatel);
    return 0;
}
