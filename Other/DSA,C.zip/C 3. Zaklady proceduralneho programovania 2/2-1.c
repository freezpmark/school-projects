#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int id;
    char meno[101];
    char destinacia[101];
    int rok;
    int dlzka_pobytu;
} ZAJAZD;

int nacitaj(ZAJAZD *zaznam)
{
    int i = 0;
    while (1) {
        scanf("%d", &zaznam[i].id);
        if ((zaznam[i].id >= 0) && (zaznam[i].id <= 100)) {
            scanf("%s", zaznam[i].meno);
            scanf("%s", zaznam[i].destinacia);
            scanf("%d", &zaznam[i].rok);
            scanf("%d", &zaznam[i].dlzka_pobytu);
            i++;
        }
        else
            break;
    }
    return i;
}

void vypis(int dlzka, ZAJAZD *zaznam)
{
    int i = 0;
    for ( ; i < dlzka ; i++)
        printf("%d %s %s %d %d\n", zaznam[i].id, zaznam[i].meno, zaznam[i].destinacia, zaznam[i].rok, zaznam[i].dlzka_pobytu);
}

void najnovsie(int dlzka, ZAJAZD *zaznam)
{
    int i = 0, pocet;
    int max = zaznam[i].rok;
    int najdlhsi = zaznam[i].dlzka_pobytu;
    pocet = 1;
    for (i = 1 ; i <= dlzka; i++) {
        if (zaznam[i].rok > max) {
            max = zaznam[i].rok;
            pocet = 1;
            najdlhsi = zaznam[i].dlzka_pobytu;
        }
        else if (zaznam[i].rok == max) {
            pocet++;
            if (najdlhsi < zaznam[i].dlzka_pobytu)
                najdlhsi = zaznam[i].dlzka_pobytu;
        }
    }
    printf("%d %d", najdlhsi, pocet);
}

int main()
{
    ZAJAZD zaznam[100];
    int dlzka;
    dlzka = nacitaj(zaznam);
    vypis(dlzka, zaznam);
    najnovsie(dlzka, zaznam);
    return 0;
}
