#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *fr;
    fr = fopen("cisla.txt", "r");
    int b = 0, max = -1, i, index = -1;
    int pole[20];
    int c;
    int *p;

  p = &pole[0];

    while ((b < 20) && (fscanf(fr, "%d", &c)) != EOF) {
        *p = c;

        if (*p > max) {
            max = *p;
            index = b;
        }
        b++;
        p++;
    }

    p = &pole[0];
    for (i = 0; i < b; i++)
{
    printf("%d ", *p);
    p++;
}
putchar('\n');

printf("%d %d", index, max);
return 0;
}
