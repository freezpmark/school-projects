#include <stdio.h>
#include <stdlib.h>

int *pole;
int velkost;

int alloc() {
    int i;
    pole = (int *)malloc(10*sizeof(int));
    velkost = 10;
    for (i=0;i<10;i++) {
        pole[i] = i+1;
    }
    return 1;
}

int print() {
    if (pole == 0) {
        return 0;
    }
    int i;
    for (i=0;i<velkost;i++) {
        printf("%d\n", pole[i]);
    }
    return 1;
}

int seek() {
    if (pole == 0) {
        return 0;
    }
    int hladane, vkladane, vyskyt = 0, i, velkost2 = 0;
    int *pole2;
    scanf("%d %d", &hladane, &vkladane);
    for (i = 0; i < velkost; i++) {
        if (pole[i] == hladane)
            vyskyt++;
    }
    if (vyskyt > 0) {//realokacia
        pole2 = (int *)malloc((velkost + vyskyt) * sizeof(int));
        for (i = 0; i < velkost; i++) {
            pole2[velkost2] = pole[i];
            if (pole[i] == hladane) {
                velkost2++;
                pole2[velkost2] = vkladane;
            }
            velkost2++;
        }
        free(pole);
        pole = pole2;
        velkost = velkost2;
    }
    return 0;
}

int prec() {
    if (pole == 0) {
        return 0;
    }
    int index, zmensenie, velkost2, i;
    int *pole2;
    scanf("%d", &index);
    zmensenie = velkost / index;
    velkost2 = velkost - zmensenie;
    pole2 = (int *)malloc(velkost2 * sizeof(int));
    for (i = 0; i < velkost2; i++) {
        pole2[i] = pole[i + i/index];
    }
    free(pole);
    pole = pole2;
    velkost = velkost2;
    return 1;
}

int main()
{
    char c;

    while ((scanf("\n%c", &c) > 0) && c != 'k') {
        switch (c) {
            case 'g': alloc(); break;
            case 'v': print(); break;
            case 'p': seek(); break;
            case 'z': prec(); break;
        }
    }

return 0;
}
