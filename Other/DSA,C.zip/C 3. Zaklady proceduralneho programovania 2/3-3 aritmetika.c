#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, a;
    char *slovo, *znak;
    scanf("%d\n", &n);
    slovo = (char *)malloc(n * sizeof(char));
    znak = &slovo[0]; // odpredu

    for (a = 0 ; a < n; a++) {
        *znak = getchar();
        znak++;
    }

    znak = &slovo[n-1]; // odzadu
    for (a = n-1; a >= 0; a--) {
        putchar(*znak);
        znak--;
    }
return 0;
}
