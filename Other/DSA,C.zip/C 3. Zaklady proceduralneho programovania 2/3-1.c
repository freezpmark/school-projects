#include <stdio.h>
#include <stdlib.h>

int main()
{
  int *a, *b, c, **d;
  if ((a = (int *)malloc(sizeof(int))) == NULL)
    printf("Koniec sveta.");
  b = (int *)malloc(sizeof(int));
  d = &a;
  scanf("%d %d %d\n", a, b, &c);
  printf("%d + %d + %d = %d", **d, *b, c, **d + *b + c);
  free(a);
  free(b);
  return 0;
}
