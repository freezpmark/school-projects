#include <stdio.h>

int najdi(char *retaz, char hladany, int *index)
{
  int a = 0;
  int pocet = 0;
  char *znak;
  znak = &retaz[0];

  while (*znak != '\0') {
    if (*znak == hladany) {
    	pocet++;
    	if (pocet == 1)
          *index = a;
  	}
    znak++;
  }
  if (pocet == 0)
    *index = *index-1;
  return pocet;
}

int main()
{
	char retaz[101];
  	int index;
  	int pocet;
  	char hladany;

  scanf("%s %c", retaz, &hladany);
  pocet = najdi(retaz, hladany, &index);
  printf("%d %d", pocet, index);
  return 0;
}
