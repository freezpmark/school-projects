#include <stdio.h>
#include <stdlib.h>

#define N 20

int symetricka(int **m, int n)
{
    int i, j;
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            if (i != j) {
                if (m[i][j] != m[j][i])
                    return 0;
            }
        }
    }
    return 1;
}

int diagonalna(int **m, int n)
{
    int i, j;
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            if (i != j) {
                if (m[i][j] != 0)
                    return 0;
                else
                    continue;
            }
        }
    }
    return 1;
}

int main()
{
  int i, j, n;
  while(scanf("%d", &n) && n != 0) {
    int **m;
    m = malloc(n*sizeof(int *));
    for (i = 0; i < n; i++){
        m[i] = malloc(n+sizeof(int));
        for (j = 0; j < n; j++)
            scanf("%d", &m[i][j]);
    }
    if (symetricka(m, n) == 1)
        if (diagonalna(m, n) == 1)
            printf("Matica je symetricka a diagonalna\n");
        else
            printf("Matica je symetricka\n");
        else
            printf("Matica nieje symetricka\n");

    for (i = 0; i < n; i++)
        free(m[i]);
    free(m);
  }

  return 0;
}
