#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
	char meno[30];           // 31?
	char priezvisko[30];
	int typZamestnanca;
	float mzda;
	char datumNastupu[9];
} person;

void vypis(FILE **subor)
{
	if (*subor == NULL)
	{
		if ((*subor = fopen("zamestnanci.txt", "r")) == NULL)
		{
			printf("Neotvoreny subor\n");
			return;
		}
	}
	person zamestnanec;

	while (fscanf(*subor, "%30s\n%30s\n%d\n%f\n%s\n#", zamestnanec.meno, zamestnanec.priezvisko, &zamestnanec.typZamestnanca, &zamestnanec.mzda, zamestnanec.datumNastupu) == 5) {
        printf("meno: %s\n", zamestnanec.meno);
        printf("priezvisko: %s\n", zamestnanec.priezvisko);

        if (zamestnanec.typZamestnanca == 1)
            printf("riadiaci pracovnik\n");
        else if (zamestnanec.typZamestnanca == 0)
            printf("bezny zamestnanec\n");

        printf("hruba mzda: %.2f\n", zamestnanec.mzda);
        printf("datum nastupu: %s\n#\n", zamestnanec.datumNastupu);
        }
}

void odmena(FILE *subor)
{
    if (subor == NULL)
        return;

	person zamestnanec;
    char datum[9], c_rok[5], c_mesiac[3], c_den[3];
    char cp_rok[5], cp_mes[3], cp_den[3];
    int i;
	float k;
    scanf("%8s", datum);

    for (i = 0; i < 4; i++)
        c_rok[i] = datum[i];
    for (i = 0; i < 2; i++)
		c_mesiac[i] = datum[i + 4];
    for (i = 0; i < 2; i++)
        c_den[i] = datum[i + 6];

    int rok = atoi(c_rok);
    int mesiac = atoi(c_mesiac);
    int den = atoi(c_den);

    fseek(subor, 0, SEEK_SET);

	while (fscanf(subor, "%30s\n%30s\n%d\n%f\n%s\n#", zamestnanec.meno, zamestnanec.priezvisko, &zamestnanec.typZamestnanca, &zamestnanec.mzda, zamestnanec.datumNastupu) == 5) {

        for (i = 0; i < 4; i++)
			cp_rok[i] = zamestnanec.datumNastupu[i];
        for (i = 0; i < 2; i++)
			cp_mes[i] = zamestnanec.datumNastupu[i + 4];
        for (i = 0; i < 2; i++)
			cp_den[i] = zamestnanec.datumNastupu[i + 6];

        int p_rok = atoi(cp_rok);
        int p_mes = atoi(cp_mes);
        int p_den = atoi(cp_den);

        if (p_rok + 3 > rok)
            continue;
        else if (p_rok + 3 == rok) {
            if (p_mes < mesiac)
                continue;
            else if (p_mes == mesiac) {
                if (p_den < den)
                    continue;
            }
        }

		if (zamestnanec.typZamestnanca == 1)
			k = 2;
		else if (zamestnanec.typZamestnanca == 0)
			k = 1.5;

		printf("%s %s %.2f\n", zamestnanec.meno, zamestnanec.priezvisko, zamestnanec.mzda * k);
    }
}

int nacitanie(FILE *subor, float **pole_mzdy)
{
	if (subor == NULL)
		return 0;

    int pocet_zaznamov = 0, i = 0;
    person zamestnanec;

    fseek(subor, 0, SEEK_SET);

    while (fscanf(subor, "%30s\n%30s\n%d\n%f\n%s\n#", zamestnanec.meno, zamestnanec.priezvisko, &zamestnanec.typZamestnanca, &zamestnanec.mzda, zamestnanec.datumNastupu) == 5)
        pocet_zaznamov++;

    if (*pole_mzdy != 0)
        free(*pole_mzdy);

    *pole_mzdy = (float *)malloc(pocet_zaznamov*sizeof(float));

    fseek(subor, 0, SEEK_SET);

    while (fscanf(subor, "%30s\n%30s\n%d\n%f\n%s\n#", zamestnanec.meno, zamestnanec.priezvisko, &zamestnanec.typZamestnanca, &zamestnanec.mzda, zamestnanec.datumNastupu) == 5) {
        (*pole_mzdy)[i] = zamestnanec.mzda;
        i++;
    }
    return pocet_zaznamov;
}

void suma(float *pole_mzdy, int pocet)
{
    if (pole_mzdy == 0)
        printf("Pole nie je vytvorene\n");
    else {
        int i, j, dlzka_sumy;

// NACITANIE SUMY
        float sum = 0;
        char *sum_znak;
        sum_znak = (char *)malloc(20 * sizeof(char));
        for (i = 0; i < pocet; i++) {
            sum += pole_mzdy[i];
            pole_mzdy[i] *= 100;
        }
        sum *= 100;
        itoa(sum, sum_znak, 10);
        dlzka_sumy = strlen(sum_znak);

        sum_znak[dlzka_sumy+1] = '\0';                  //pridavanie bodky do sumy
        sum_znak[dlzka_sumy] = sum_znak[dlzka_sumy-1];
        sum_znak[dlzka_sumy-1] = sum_znak[dlzka_sumy-2];
        sum_znak[dlzka_sumy-2] = '.';
// NACITANIE vsetkych poli
        char **cpole_mzdy;
        int *dlzka_mzdy;

        dlzka_mzdy = (int *)malloc(pocet * sizeof(int));
        cpole_mzdy = (char **)malloc(pocet * sizeof(char*));
        for (i = 0; i < pocet; i++)
            cpole_mzdy[i] = (char *)malloc(20 * sizeof(char));

        for (i = 0; i < pocet; i++) {
            itoa(pole_mzdy[i], cpole_mzdy[i], 10);      // PREVOD kazdeho ins_pole_mzdy na string
            dlzka_mzdy[i] = strlen(cpole_mzdy[i]);      // zistenie ich dlzky
        }

        for (i = 0; i < pocet; i++)
            pole_mzdy[i] *= 0.01;

        for (i = 0; i < pocet; i++) {
            cpole_mzdy[i][dlzka_mzdy[i]] = cpole_mzdy[i][dlzka_mzdy[i]-1];      // pridavanie bodky do vsetky poli
            cpole_mzdy[i][dlzka_mzdy[i]-1] = cpole_mzdy[i][dlzka_mzdy[i]-2];
            cpole_mzdy[i][dlzka_mzdy[i]-2] = '.';
            }
// VYPIS
        int pocet_prazdnych;
        for (i = 0; i < pocet; i++) {
            pocet_prazdnych = dlzka_sumy % dlzka_mzdy[i];
            for(j = 0; j < pocet_prazdnych; j++)
                putchar(' ');
            for(j = 0; j <= dlzka_mzdy[i]; j++)
                printf("%c", cpole_mzdy[i][j]);
            putchar('\n');
        }

        for(i = 0; i <= dlzka_sumy; i++)
            putchar('-');

        printf("\n%s\n", sum_znak);
// UVOLNENIE PAMATE
        free(sum_znak);
        for (i = 0; i < pocet; i++)
            free(cpole_mzdy[i]);
        free(cpole_mzdy);
        free(dlzka_mzdy);


   /*     int i;
        float sum = 0;
        float ins_pole_mzdy[pocet];
        for (i = 0; i < pocet; i++)
            ins_pole_mzdy[i] = pole_mzdy[i];

        for (i = 0; i < pocet; i++) {
            sum += ins_pole_mzdy[i];
        }

        if (sum < 10) {
            for(i = 0; i < pocet; i++)
                printf("%4.2f\n", ins_pole_mzdy[i]);
            printf("----\n");
        }
        else if (sum < 100) {
            for(i = 0; i < pocet; i++)
                printf("%5.2f\n", ins_pole_mzdy[i]);
            printf("-----\n");
        }
        else if (sum < 1000) {
            for(i = 0; i < pocet; i++)
                printf("%6.2f\n", ins_pole_mzdy[i]);
            printf("------\n");
        }
        else if (sum < 10000) {
            for(i = 0; i < pocet; i++)
                printf("%7.2f\n", ins_pole_mzdy[i]);
            printf("-------\n");
        }
        else if (sum < 100000) {
            for(i = 0; i < pocet; i++)
                printf("%8.2f\n", ins_pole_mzdy[i]);
            printf("--------\n");
        }
        else if (sum < 1000000) {
            for(i = 0; i < pocet; i++)
                printf("%9.2f\n", ins_pole_mzdy[i]);
            printf("---------\n");
        }
        printf("%.2f\n", sum);   */
    }
}

void histogram(float *pole_mzdy, int pocet)
{
	if (pole_mzdy == 0)
		printf("Pole nie je vytvorene\n");
	else
	{
        int i, j, k, dlzka_retazca;
        int cislica[10]; // 0-9
        char str[7]; // max 5 ciferne
	    int max = 0;
	    int znak;

	    for (i = 0; i < 10; i++) // cislice vynulujeme
            cislica[i] = 0;
	    for (i = 0; i < pocet; i++) // float -> int
            pole_mzdy[i] *= 100;
		for (i = 0; i < pocet; i++) // vyber poli
		{
			itoa(pole_mzdy[i], str, 10); // konvert na string
			dlzka_retazca = strlen(str); // dlzka retazca
			for(j = 0; j < dlzka_retazca; j++) { // pre kazdy znak
                znak = str[j] - '0';            // char -> int
                for(k = 0; k < 10; k++)          // vyhladava cisla
                if (znak == k)
                    cislica[k]++;
			}
        } // mame pocet vsetkych cislic

        for (i = 0; i < pocet; i++)
            pole_mzdy[i] *= 0.01;

		for(i = 0; i < 10; i++) // najdeme cislicu ktora ma najvacsiu hodnotu
            if(cislica[i] > max)
                max = cislica[i];

        for(i = 0; i < 10; i++) {
            printf("%d:", i);
            for(j = 0; j < max; j++) {
                if (cislica[i] > j)
                    putchar('*');
                else
                    putchar('-');
            }
            putchar('\n');
        }
	}
}

/* void poistenie(float *pole_mzdy, int pocet)
{
   if (pole_mzdy == 0)
		return;
    int i, j, vyskyt = 0;
    for (i = 0; i < pocet; i++)
        if (pole_mzdy[i] >= 500.00)
            vyskyt++;

    float prip, *pole_mzdy5, *pole_mzdy3;

    pole_mzdy5 = (float *) malloc ((pocet+vyskyt)*sizeof(float));
    pole_mzdy3 = (float *) malloc ((pocet+vyskyt)*sizeof(float));

    for (i = 0, j = 0; j < (vyskyt+pocet); i++, j+=2) {
        if (pole_mzdy[j] <= 1500.00)
            pole_mzdy3[i] = pole_mzdy[j] * 0.05;
        else if ((pole_mzdy[j] >= 1500.00) && (pole_mzdy[j] <= 5000.00))
            pole_mzdy[i] = pole_mzdy[j] - 1500.00;
            prip = 1500.00 * 0.05;
            pole_mzdy[i] = pole_mzdy[i] * 0.025;
            pole_mzdy[i] += prip;
    }

    pole_mzdy5 = (float *) malloc ((pocet+vyskyt)*sizeof(float));
    for (i = 0; i < (pocet+vyskyt); i++) {
        if (i % 2 == 0)
            pole_mzdy5[i] = pole_mzdy[i];
        else if (i % 2 == 1)
            pole_mzdy5[i] = pole_mzdy3[i];
    }
    free(pole_mzdy);
    float *pole_mzdy;
    pole_mzdy = (float *) malloc ((pocet+vyskyt)*sizeof(float));
    // REALLOC...
    *pole_mzdy = *pole_mzdy5;
    free(pole_mzdy5);
    free(pole_mzdy3);
}
    // OUT OF TIME...


void zmaz(float *pole_mzdy, int pocet)
{
    float r;
    int i, j, vyskyt = 0;
    scanf("%f\n", &r);
    if (pole_mzdy == 0)
		return;
    for (i = 0; i < pocet; i++)
        if (pole_mzdy[i] < r)
            vyskyt++;

    if (vyskyt == 0)
        return;

    float *pole_mzdy2;
    pole_mzdy2 = (float *) malloc ((pocet-vyskyt)*sizeof(float));

    for (i = 0, j = 0; i < pocet; i++) {
        if (pole_mzdy[i] < r)
            continue;
        else {
            pole_mzdy2[j] = pole_mzdy[i];
            j++;
        }
    }
    *pole_mzdy = *pole_mzdy2;
}
*/

int main()
{
	char str[20];
	int repeat = 1;
	FILE *subor = NULL;
    float *pole_mzdy = NULL;
    int pocet = 0;

	while (repeat) {
		scanf("%s", str);
		if (strcmp(str, "vypis") == 0)
			vypis(&subor);
		else if (strcmp(str, "odmena") == 0)
			odmena(subor);
		else if (strcmp(str, "nacitanie") == 0)
			pocet = nacitanie(subor, &pole_mzdy);
		else if (strcmp(str, "suma") == 0)
			suma(pole_mzdy, pocet);
		else if (strcmp(str, "histogram") == 0)
			histogram(pole_mzdy, pocet); /*
        else if (strcmp(str, "poistenie") == 0)
            poistenie(pole_mzdy, pocet);
        else if (strcmp(str, "zmaz") == 0)
            zmaz(pole_mzdy, pocet); */

		else if (strcmp(str, "koniec") == 0)
			repeat = 0;
    }
	if (subor != NULL)
		fclose(subor);

	if (pole_mzdy != NULL)
		free(pole_mzdy);

    return 0;
}
