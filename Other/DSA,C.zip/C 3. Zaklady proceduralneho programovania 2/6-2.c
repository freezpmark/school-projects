#include <stdio.h>
#include <stdlib.h>

void vypis_zaporne(double pole[], int n)
{
    int a;
  for (a = 0 ; a < n; a++) {
      if (*pole < 0)
		printf("%g\n", *pole);
  pole++;
  }
}

int main()
{
  int n, a;
  double *pole;
  double *pompole;

  scanf("%d", &n);
  pompole = (double *) malloc (n * sizeof(double));
    pole = &pompole[0];

  for (a=0 ; a < n; a++) {
    scanf("%lf", pompole);
    pompole++;
  }
  vypis_zaporne(pole, n);

  return 0;
}
