#include <stdio.h>
int scitanie(int c, int b)
{
    return c+b;
}
int odcitanie(int c, int b)
{
  	return c-b;
}
int nasobenie(int c, int b)
{
  	return c*b;
}
int delenie(int c, int b)
{
  	return c/b;
}

int vypocitaj(int (*fn)(int, int))
{
  	int a, b;
	scanf("%d %d", &a, &b);
	printf("%d\n", fn(a, b));
	return 0;
}


int main()
{
char a;
while((scanf("\n%c", &a) > 0) && (a != 'e'))
  switch(a) {
    case 's':
    	vypocitaj(scitanie);
    	break;
    case 'o':
    	vypocitaj(odcitanie);
    	break;
    case 'n':
    	vypocitaj(nasobenie);
    	break;
    case 'd':
    	vypocitaj(delenie);
    	break;
    default:
        printf("Operacia nie je podporovana\n");
        break;
  }
return 0;
}
