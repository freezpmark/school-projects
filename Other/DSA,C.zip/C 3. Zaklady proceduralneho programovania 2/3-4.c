#include <stdio.h>

int najdi(char *retaz, char hladany, int *index)
{
  int a = 0;
  int pocet = 0;
  while (retaz[a] != '\0') {
    if (retaz[a] == hladany) {
    	pocet++;
    	if (pocet == 1)
          *index = a;
  	}
    a++;
  }
  if (pocet == 0)
    *index = *index-1;
  return pocet;
}

int main()
{
	char retaz[101];
  	int index;
  	int pocet;
  	char hladany;

  scanf("%s %c", retaz, &hladany);
  pocet = najdi(retaz, hladany, &index);
  printf("%d %d", pocet, index);
  return 0;
}
