#include <stdio.h>

int zaporne(double pole[], int n)
{
  int pocet = 0;
   for ( ; n > 0; n--) {
        if (*pole < 0)
            pocet++;
        pole++;
    }
  return pocet;
}

int main()
{
  double a[100];
  int n, i;
  scanf("%d", &n);
    if (n > 100)
        return 1;
  for (i = 0; i < n; i++)
    scanf("%lf", &a[i]);
  printf("%d\n", zaporne(a, n));
  return 0;
}
