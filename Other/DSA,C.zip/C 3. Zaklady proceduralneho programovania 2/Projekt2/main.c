#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct car{
	char kategoria[51];
	char znacka[51];
	char predajca[101];
	float cena;
	int rok_vyroby;
	char stav_vozidla[201];
	struct car *dalsi;
} CAR;

void load_file(char *str, int n, FILE *subor) {
        int i = 0;
        fgets(str, n, subor);
        while (str[i] != '\n' && str[i] != '\0')
            i++;
        str[i] = '\0';
}

CAR *nacitanie(CAR *zoznam, int *pocet) {
    FILE *subor;
    if ((subor = fopen("auta.txt", "r")) == NULL) {
        printf("Zaznamy neboli nacitane\n");
        return NULL;
    }

    char c;
    float pom_cena;
    int pom_rok_vyroby;



    CAR *nasl;
// ak existuje zoznam, uvolnime pamat celeho zoznamu
    if (zoznam != NULL)
        *pocet = 0;
    while (zoznam != NULL) {
        nasl = zoznam->dalsi;
        free(zoznam);
        zoznam = nasl;
    }

    CAR *akt = NULL;
    while(1) {
        c = '\0';
        fscanf(subor, "%c\n", &c);
        if (c != '$')
            break;

        if (akt == NULL) {
            if ((zoznam = akt = malloc(sizeof(CAR))) == NULL) {
                printf("Nedostatok pamate\n");
                return NULL;
            }
        } else {
            if ((akt->dalsi = malloc(sizeof(CAR))) == NULL) {
                printf("Nedostatok pamate\n");
                return NULL;
            }
            akt = akt->dalsi;
        }

        load_file(akt->kategoria, 51, subor);
        load_file(akt->znacka, 51, subor);
        load_file(akt->predajca, 101, subor);
        fscanf(subor, "%f\n", &pom_cena);
        akt->cena = pom_cena;
        fscanf(subor, "%d\n", &pom_rok_vyroby);
        akt->rok_vyroby = pom_rok_vyroby;
        load_file(akt->stav_vozidla, 201, subor);
        (*pocet)++;
    }

    akt->dalsi = NULL;
    printf("Nacitalo sa %d zaznamov\n", *pocet);

    if (fclose(subor) == EOF) {
        printf("Subor sa nepodarilo zatvorit\n");
        return NULL;
    };
    return zoznam;
}

void vypis(CAR *zoznam) {
    if(zoznam == NULL)
        return;

    CAR *akt;
    akt = zoznam;

    int i;
    for(i = 1; akt != NULL; i++, akt = akt->dalsi) {
        printf("%d.\nkategoria: %s\n", i, akt->kategoria);
        printf("znacka: %s\n", akt->znacka);
        printf("predajca: %s\n", akt->predajca);
        printf("cena: %.2f\n", akt->cena);
        printf("rok_vyroby: %d\n", akt->rok_vyroby);
        printf("stav_vozidla: %s\n", akt->stav_vozidla);
    }
}

void load_std(char *str, int n) {
        int i = 0;
        gets(str);
        while (str[i] != '\n' && i != 50)
            i++;
        str[i] = '\0';
}

CAR * pridaj(CAR *zoznam, int *pocet) {
    int p;
    scanf("\n%d\n", &p);

    if(p < 1)
        return zoznam;

    int i, pom_rok_vyroby;
    float pom_cena;

//pridanie jednoprvkoveho zoznamu
    if (zoznam == NULL) {
        zoznam = malloc(sizeof(CAR));

        load_std(zoznam->kategoria, 51);
        load_std(zoznam->znacka, 51);
        load_std(zoznam->predajca, 101);
        scanf("%f\n", &pom_cena);
        zoznam->cena = pom_cena;
        scanf("%d\n", &pom_rok_vyroby);
        zoznam->rok_vyroby = pom_rok_vyroby;
        load_std(zoznam->stav_vozidla, 201);
        zoznam->dalsi = NULL;

    }
    else {
        CAR *pred;
        CAR *vklad;
        CAR *akt = zoznam;

//pridanie na koniec zoznamu
        if (p > *pocet) {
            while(akt->dalsi != NULL)
                akt = akt->dalsi;
            akt->dalsi = malloc(sizeof(CAR));

            load_std(akt->dalsi->kategoria, 51);
            load_std(akt->dalsi->znacka, 51);
            load_std(akt->dalsi->predajca, 101);
            scanf("%f\n", &pom_cena);
            akt->dalsi->cena = pom_cena;
            scanf("%d\n", &pom_rok_vyroby);
            akt->dalsi->rok_vyroby = pom_rok_vyroby;
            load_std(akt->dalsi->stav_vozidla, 201);

            akt->dalsi->dalsi = NULL;
        }
//pridanie na p-tej pozicii
        else {
            for(i = 1; i <= *pocet; i++) {
                if(i == p) {
                    vklad = malloc(sizeof(CAR));

                    load_std(vklad->kategoria, 51);
                    load_std(vklad->znacka, 51);
                    load_std(vklad->predajca, 101);
                    scanf("%f\n", &pom_cena);
                    vklad->cena = pom_cena;
                    scanf("%d\n", &pom_rok_vyroby);
                    vklad->rok_vyroby = pom_rok_vyroby;
                    load_std(vklad->stav_vozidla, 201);

                    if(i == 1)
                        vklad->dalsi = akt;
                    else
                        pred->dalsi = vklad;
                        vklad->dalsi = akt;
                    break;
                }
                else {
                    pred = akt;
                    akt = akt->dalsi;
                }
            }
        }
    (*pocet)++;
    }
    return zoznam;
}

CAR *zmaz(CAR *zoznam) {
    if (zoznam == NULL)
        return NULL;

    int n = 0;
    char c[51];
    char ret[51];

    scanf("%s", c);
    strlwr(c);

    CAR *akt;
    akt = zoznam;

    //vsetky okrem prveho
    while(akt->dalsi != NULL) {
        strcpy(ret, akt->dalsi->znacka);
        strlwr(ret);
        if (strstr(ret, c) != NULL) {
            CAR *navymazanie = akt->dalsi;
            akt->dalsi = navymazanie->dalsi;
            free(navymazanie);
            n++;
        }
        else {
            akt = akt->dalsi;
        }
    }

    //prvy prvok
    strcpy(ret, zoznam->znacka);
    strlwr(ret);
    if (strstr(ret,c) != NULL) {
        CAR *navymazanie = zoznam;
        zoznam = zoznam->dalsi;
        free(navymazanie);
        n++;
    }
    printf("Vymazalo sa %d zaznamov\n", n);
    return zoznam;
}

void hladaj(CAR *zoznam) {
    float c;
    int i = 1;
    scanf("\n%f", &c);

    CAR *akt;
    akt = zoznam;

    while(akt != NULL) {
        if (akt->cena <= c) {
            printf("%d.\nkategoria: %s\n", i, akt->kategoria);
            printf("znacka: %s\n", akt->znacka);
            printf("predajca: %s\n", akt->predajca);
            printf("cena: %.2f\n", akt->cena);
            printf("rok_vyroby: %d\n", akt->rok_vyroby);
            printf("stav_vozidla: %s\n", akt->stav_vozidla);
            i++;
        }
        akt = akt->dalsi;
    }
    if (i == 0)
        printf("V ponuke nie su auta s danou a mensou cenou\n");
}

void aktualizuj(CAR *zoznam) {
    int rok_v, zlava, n = 0;
    scanf("\n%d", &rok_v);
    scanf("\n%d", &zlava);

    CAR *akt;
    for(akt = zoznam; akt != NULL; akt = akt->dalsi) {
        if (akt->rok_vyroby == rok_v) {
            akt->cena = (akt->cena * (100-zlava)) / 100;
            akt->cena = ((int)(akt->cena*100+0.5))/ 100.0;
            n++;
        }
    }
    printf("Aktualizovalo sa %d zaznamov\n", n);
}


int main()
{
    printf("nacitanie - nacitanie zaznamov zo suboru auta.txt\n");
    printf("vypis - vypise zoznam zaznamov\n");
    printf("pridaj - pridanie zaznamu do zoznam (pozicia)\n");
    printf("zmaz - zmazanie zaznamov (podla znacky auta)\n");
    printf("hladaj - vyhlada a vypise vsetky zaznamy podla ceny ponuky (vsetky mensie ceny)\n");
    printf("aktualizuj - aktualizovanie ceny podla (rok), (zlava)\n\n");

    CAR *zoznam = NULL;
	char str[15];
	int pocet = 0;



	while (1) {
		scanf("%s", str);
		if (strcmp(str, "nacitanie") == 0)
			zoznam = nacitanie(zoznam, &pocet);
        else if (strcmp(str, "vypis") == 0)
			vypis(zoznam);
		else if (strcmp(str, "pridaj") == 0)
			zoznam = pridaj(zoznam, &pocet);
		else if (strcmp(str, "zmaz") == 0)
			zoznam = zmaz(zoznam);
		else if (strcmp(str, "hladaj") == 0)
			hladaj(zoznam);
        else if (strcmp(str, "aktualizuj") == 0)
            aktualizuj(zoznam);
		else if (strcmp(str, "koniec") == 0)
			break;
    }

    for( ; zoznam != NULL; zoznam = zoznam->dalsi)
        free(zoznam);


    return 0;
}
