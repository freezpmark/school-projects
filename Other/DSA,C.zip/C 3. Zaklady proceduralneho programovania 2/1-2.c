#include <stdio.h>
#include <stdlib.h>

int vlozPodretazec(char ret[], char pod[], int p, int n)
{
    int DlzkaRet = strlen(ret);
    int DlzkaPod = strlen(pod);
    if ((p > DlzkaRet) || (n < DlzkaRet + DlzkaPod))
        return 0;
    else
    {
        int a;
        for (a = 1; a <= DlzkaRet-p; a++)
            ret[DlzkaRet-a+DlzkaPod] = ret[DlzkaRet-a];
        for (a = 0; a < DlzkaPod; a++)
            ret[p+a] = pod[a];
        return 1;
    }
}

int main()
{
    char retazec[100] = "MamProgramovanie";
    if (!vlozPodretazec(retazec, "Rad", 3, 100))
        printf("Nepodarilo sa vlozit podretazec");
    else
        printf("%s", retazec);
    return 0;
}
