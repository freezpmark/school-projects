#include <stdio.h>
#include <stdlib.h>

int main()
{
	int n, a;
  	char *slovo;
  	scanf("%d\n", &n);   // \n preto, lebo inak by \n islo do prveho getcharu (slovo[a])
  	slovo = (char *)malloc(n * sizeof(char));
  for (a = 0 ; a < n; a++)
    slovo[a] = getchar();

  for (a = n-1; a >= 0; a--)
    putchar(slovo[a]);

  free(slovo);
  return 0;
}
