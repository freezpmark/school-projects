#include <stdio.h>
int cislica(char c)
{
  if (c >= '0' && c <= '9')
    return 1;
  else
    return 0;
}

int male_pismeno(char c)
{
  if (c >= 'a' && c <= 'z')
    return 1;
  else
    return 0;
}

int velke_pismeno(char c)
{
  if (c >= 'A' && c <= 'Z')
    return 1;
  else
    return 0;
}

int biely(char c)
{
  if ((c == ' ') || (c == '\n') || (c == '\t'))
    return 1;
  else
    return 0;
}

void zisti(int (*funkcia)(char), FILE *subor)
{
    int pocet = 0;
    char a;

    while ((a = getc(subor)) != EOF)
        if ((funkcia(a)) == 1)
            pocet++;

    printf("%d\n", pocet);
}

int main()
{
  int N;
  char m;
  FILE *subor;

  scanf("%d", &N);
  for ( ; N > 0; N--) {
        scanf("\n%c", &m);
        subor = fopen("ZNAKY.TXT", "r");
        switch (m) {
        case 'b':
            zisti(biely, subor);
            break;
        case 'v':
            zisti(velke_pismeno, subor);
            break;
        case 'm':
            zisti(male_pismeno, subor);
            break;
        case 'c':
            zisti(cislica, subor);
            break;
        }

    }
            fclose(subor);
return 0;
}
