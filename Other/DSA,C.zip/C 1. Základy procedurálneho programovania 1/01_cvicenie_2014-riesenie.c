#include <stdio.h>

void first() {
    int a, b, c;
  	scanf("%d %d %d", &a, &b, &c);
    printf("%d\n", a*b*c);
}

void second() {
    float r, o, s;
    scanf("%f", &r);
    o = 2*3.14159*r;
  	s = 3.14159*r*r;
  	printf("Kruh s polomerom %.2f: obvod = %.2f, obsah = %.2f\n", r, o, s);
}

void third() {
    float x, y, z, p;
    scanf("%f %f %f", &x, &y, &z);
    p = (x+y+z)/3;
    printf("Priemer cisel %g %g %g je: %g\n", x, y, z, p);
}

void forth() {
    float a;
    scanf("%f", &a);
    printf("Cena bez dane: %.0f\nPredajna cena s danou 20%%: %.1f\n", a, a*1.2);
}

void fifth() {
    float d, e, f;
    scanf("%f %f", &d, &e);
	d = d*d*0.0001;
	f = e/d;
	printf("BMI: %.3f\n", f);
}

void sixth() {
    printf("\t\\*/\"Toto\" je na '100%%' zarucene\\*/");
}

int main()
{
    printf("***1. program***\n");
  	first();
  	printf("\n***2. program***\n");
  	second();
  	printf("\n***3. program***\n");
  	third();
  	printf("\n***4. program***\n");
  	forth();
  	printf("\n****5. program***\n");
  	fifth();
  	printf("\n***6. program***\n");
  	sixth();
  	printf("\n\n");
  	return 0;
}
