#include <stdio.h>

void first() {      // addition
    int a, b, N;
  	float min = 10000, max = -10000;
    scanf("%d", &N);
    float pole[N];
    for (a = 0, b = 1; a < N; a++, b++) {
        scanf("%f", &pole[a]);
    }
    for (a = 0; a < N; a++){
        if (pole[a] < min)
            min = pole[a];
        if (pole[a] > max)
            max = pole[a];
    }
    printf("Minimum: %.2f\nMaximum: %.2f\n", min, max);
}

void second() {     // addition
    int N, a, b, c = 0;
    scanf("%d", &N);
    for (a = 1; a <= N; a++) {
        scanf("%d", &b);
        if ((b > 0) && (b <= 100))
            c++;
    }
    printf("%d\n", c);
}

void third() {
    char z;
  	int b = 0, c = 0;
    do {
        scanf("%c", &z);
        if (z >= 'a' && z <= 'z')
            b++;
        if (z >= 'A' && z <= 'Z')
            c++;
        } while (z != '\n');
    printf("%d %d\n", b, c);
}

void forth() {
    int a, b, c;
    scanf("%d %d", &a, &b);
    if (a > b) {
        c = a;
        a = b;
        b = c;
    }
    while(a <= b)
        if(a++ % 3 == 0)
            printf("%d ", a-1);
    printf("\n");
}

void fifth() {
    int a, b, c, d;
    scanf("%d %d %d", &a, &b, &d);
    if (a > b) {
        c = a;
        a = b;
        b = c;
    }
    while(a <= b)
        if (a++ % d == 0)
            printf("%d ", a-1);
    printf("\n");
}

void sixth() {
    int N, a, b, podvaha = 0, normal = 0, nadvaha = 0, obezita = 0;
    float vyska, vaha;
    scanf("%d", &N);
    float BMI[N];

    for (b = 0; b < N; b++) {
        scanf("%f %f", &vyska, &vaha);
        BMI[b] = vaha / ((vyska/100.) * (vyska/100.));
        if (BMI[b] > 30)
            obezita++;
        if (BMI[b] > 25 && BMI[b] < 30)
            nadvaha++;
        if (BMI[b] > 18.5 && BMI[b] < 25)
            normal++;
        if (BMI[b] <=18.5)
            podvaha++;
    }

    for (a = 0; a < N; a++)
        printf("%.2f\n", BMI[a]);

    printf("Podvaha: %d\n", podvaha);
    printf("Normalna hmotnost: %d\n", normal);
    printf("Nadvaha: %d\n", nadvaha);
    printf("Obezita: %d\n", obezita);
}

void seventh() {
    int a, b, c, d;
    d = 1;
    scanf("%d", &a);
    for (b = 1; b <= a; b++) {
        for (c = 1; c <= b; c++, d++)
            if (b >= c)
                printf("%2d ", d);
        printf("\n");
  	}
}

void eighth() {
    int a, b, c;
    scanf("%d", &a);
    if (a < 1 || a > 15) {
      	printf("Cislo nie je z daneho intervalu");
  		return;
    } else {
        int d = a;
        for (b = 1; b <= a; b++, d--) {
            printf("%d: ", b);
            for (c = 1; c <= d; c++)
                printf("%2d ", c);
            printf("\n");
        }
    }
}

void ninth() {
    int a, b, c, d, e;
    scanf("%d", &a);
    e = a;
    for (b = 1; b <= e; b++, a--) {
        printf("%d: ", b);
        d = a;
        for (c = 1; c <= d; d--)
            printf("%2d ", d);
        printf("\n");
    }
}

void tenth() {
    int a, b, N;
    scanf("%d", &N);
    if ((N < 1) || (N > 15) || (N % 2 == 0)) {
        printf("Zly vstup");
        return;
    }
  	for (a = 1; a <= N*2-1; a++) {
        for (b = 1; b <= N; b++) {
            if (a >= b && a+b <= 2*N)
                printf("*");
            else
                printf("-");
        }
        printf("\n");
    }
}

void eleventh() {
    int a, b, N;
    scanf("%d", &N);
 	if ((N >= 1) && (N <= 15) && (N % 2 == 1)){
        for (a = 1; a <= N; a++){
            for (b = 1; b <= N; b++)
				if ((a == b) || (b == (N+1)/2) || ( a == (N+1)/2) || (a+b) == (N+1))
                    printf("*");
                else
                    printf("-");
                printf("\n");
        }
    } else
        printf("Zly vstup\n");
}

void twelfth() {
    int a, b, c, N, S;
    scanf("%d %d", &N, &S);
 	if ((N >= 1) && (N <= 15) && (N % 2 == 1)){
        for(c = 1; c <= S; c++) {
            for (a = 1; a <= N; a++){
                for (b = 1; b <= N; b++)
                    if ((a == b) || (b == (N+1)/2) || (a == (N+1)/2) || (a+b) == (N+1))
                        printf("*");
                    else
                        printf("-");
                    printf("\n");
            }
        }
    } else
        printf("Zly vstup\n");
}

void thirteenth() {
    int N, S, a, b, c;
    scanf("%d %d", &N, &S);
	if (N >= 1 && N <= 15 && N % 2 == 1) {
        for (a = 1; a <= N; a++) {
            for (c = 1; c <= S; c++)
                for (b = 1; b <= N; b++)
                    if (a == b || N/2+1 == a || N/2+1 == b || a+b == N+1)
                        printf("*");
                    else
                      	printf("-");
            printf("\n");
        }
    } else
        printf("Zly vstup");
}


int main()
{
    printf("***1. program***\n");
  	first();
  	printf("\n***2. program***\n");
  	second();
  	printf("\n***3. program***\n");
  	scanf("\n");
  	third();
  	printf("\n***4. program***\n");
  	scanf("\n");
  	forth();
  	printf("\n****5. program***\n");
  	scanf("\n");
  	fifth();
  	printf("\n***6. program***\n");
  	scanf("\n");
  	sixth();
  	printf("\n***7. program***\n");
  	scanf("\n");
  	seventh();
  	printf("\n***8. program***\n");
  	scanf("\n");
  	eighth();
  	printf("\n***9. program***\n");
  	scanf("\n");
  	ninth();
  	printf("\n***10. program***\n");
  	scanf("\n");
  	tenth();
  	printf("\n***11. program***\n");
  	scanf("\n");
  	eleventh();
  	printf("\n***12. program***\n");
  	scanf("\n");
  	twelfth();
  	printf("\n***13. program***\n");
  	thirteenth();
  	printf("\n\n");
  	return 0;
}
