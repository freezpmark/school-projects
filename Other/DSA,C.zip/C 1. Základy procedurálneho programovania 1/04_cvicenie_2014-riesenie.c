#include <stdio.h>

void first() {
    char a;
    do {
        scanf("%c", &a);
        if ((a >= 'a') && (a <= 'z'))
            printf("%c", a + 'A' - 'a');
        else if ((a >= 'A') && (a <= 'Z'))
            printf("%c", a);
        else if ((a == '\t') || (a == '\n') || (a == '\r'))
            printf(" ");
        else if (a == '*') {
            printf("%c", a);
            break;
        } else
            printf("-");
   } while (a != '*');
   printf("\n");
}

void second() {
    int a, b, pom, c = 0;
    scanf("%d %d", &a, &b);
    if (a > b) {
        pom = a;
        a = b;
        b = pom;
    }
    if ((a+1 == b) || (a == b))
        printf("Neda sa vypocitat");
    else {
        for (a++; a < b; a++)
            c += a;
        printf("%d", c);
    }
    printf("\n");
}

void third() {
    unsigned int a, b = 1;
    scanf("%d", &a);
    while(a >= 1)
        b *= a--;
    printf("%d\n", b);
}

void forth() {
    int a, b, d;
    scanf("%d %d", &a, &b);
    if (((a || b) < 1) || ((a || b) > 99))
        printf("Nespravny vstup");
    else
        for (d = 1; d <= a; d++)
            if (d % b == 0)
                printf("-- ");
            else
                printf("%d ", d);
    printf("\n");
}

void fifth() {
    int i = 0, n;
    scanf("%d", &n);
    while (i < n)
        printf("%d. \n", ++i);
}

void sixth() {
    int a, N;
    scanf("%d", &N);
    int pole[N];
    scanf("%d", &pole[0]);

    if ((pole[0] < 0) || (pole[0] > 10)) {
        printf("Postupnost nie je spravna\n");
        return;
    }
    for (a = 1; a < N; a++) {
        scanf("%d", &pole[a]);
        if ((pole[a] > 2*pole[a-1]) || (2*pole[a] < pole[a-1])) {
            printf("Postupnost nie je spravna\n");
            return;
        }
    }
    printf("Postupnost je spravna\n");
}

void seventh() {
    int N, a, b, c;
    scanf("%d", &N);
    if ((N < 1) || (N > 15))
        printf("Zly vstup");
    else
        for (a = 1, c = 0; a <= N*2-1; a++) {
            if (a >= N+1)
                c--;
            else
                c++;
            for (b = 1; b <= N; b++) {
            if ((a >= b) && (a+b <= 2*N))
                printf("%d", c % 10);
            else
                printf("-");
            }
            printf("\n");
        }
}

void eighth() {
    int N, S, V, a, b, c, m, n;
    scanf("%d %d %d", &N, &S, &V);
    if ((N < 1) || (N > 15) || ((S || V) < 1) || ((S || V) > 5))
        printf("Zly vstup");
    else
        for (m = 1; m <= V; m++)
            for (a = 1, c = 0; a <= N*2-1; a++) {
                if (a >= N+1)
                    c--;
                else
                    c++;
                for (n = 1; n <= S; n++)
                    for (b = 1; b <= N; b++)
                        if ((a >= b) && (a+b <= 2*N))
                            printf("%d", c % 10);
                        else
                            printf("-");
                printf("\n");
            }
}

void ninth() {
    FILE *fw;
    int i;
    float x;

    if ((fw = fopen("nasobky.txt","w")) == NULL) {
        printf("Neporadilo sa otvorit subor");
        return;
    }

	scanf("%f", &x);
    for (i = 1; i <= 10; i++)
        fprintf(fw,"%2d * %.2f = %.2f\n", i, x, i*x);

    if ((fclose(fw) == EOF)) {
        printf("Nepodarilo sa zatvorit subor");
        return;
    }
}

void tenth() {
    FILE *fr, *fw;
    char a, b;
    scanf("%c", &a);
    fw = fopen("novy.txt", "w");
    fr = fopen("znak.txt", "r");
    while(fscanf(fr, "%c", &b) != EOF)
        if (a == 's')
            fprintf(fw, "%c", b);
        else
            printf("%c", b);
    fclose(fw);
    fclose(fr);
    printf("\n");
}

void eleventh() {
    FILE *fr, *fa;
    char a;
    int b = 0;
    fr = fopen("vstup.txt", "r");
    fa = fopen("cisla.txt", "a");
    while(fscanf(fr, "%c", &a) != EOF){
        fprintf(fa, "%c", a);
        if (a >= 'a' && a <= 'z')
            b++;
        if (a == '\n'){
            fprintf(fa, "%d\n", b);
            b = 0;
        }
    }
    fclose(fr);
    fclose(fa);
}

void twelfth() {
    FILE *fr;
    int b = 0;
    char a;
    fr = fopen("text.txt", "r");

    while(fscanf(fr, "%c", &a) != EOF) {
        if (a == ' ')
            b++;
        if (a == 'x' || a == 'X')
            printf("Precital som X\n");
        if (a == 'y' || a == 'Y')
            printf("Precital som Y\n");
        if ((a == '#') || (a == '$') || (a == '&'))
            printf("Precital som riadiaci znak\n");
        if (a == '*') {
            printf("Koniec\n");
            break;
        }
    }
    printf("Pocet precitanych medzier: %d\n", b);
    fclose(fr);
}

void thirteenth() {
    FILE *f1, *f2;
    int c = 0, d = 0, e, f;
    char a, b;

    f1 = fopen("prvy.txt", "r");
    f2 = fopen("druhy.txt", "r");

    while((fscanf(f1, "%c", &a) != EOF) && (fscanf(f2, "%c", &b) != EOF))
        if (a != b)
            c++;

    if ((a == b) && (c == 0))
        printf("Subory su identicke\n");

    while ((e = fscanf(f1, "%c", &a) != EOF) || (f = fscanf(f2, "%c", &b) != EOF)) {
        if (e == 1)
            d++;
        else
            d++;
    }
    if (c > 0)
        printf("Pocet roznych znakov: %d\n", c);
    if (d > 0)
        printf("Jeden zo suborov je dlhsi o %d znakov\n", d);
    fclose(f1);
    fclose(f2);
}


int main()
{
    printf("***1. program***\n");
  	first();
  	printf("\n***2. program***\n");
  	scanf("\n");
  	second();
  	printf("\n***3. program***\n");
  	scanf("\n");
  	third();
  	printf("\n***4. program***\n");
  	scanf("\n");
  	forth();
  	printf("\n****5. program***\n");
  	scanf("\n");
  	fifth();
  	printf("\n***6. program***\n");
  	scanf("\n");
  	sixth();
  	printf("\n***7. program***\n");
  	scanf("\n");
  	seventh();
  	printf("\n***8. program***\n");
  	scanf("\n");
  	eighth();
  	printf("\n***9. program***\n");
  	scanf("\n");
  	ninth();
  	printf("\n***10. program***\n");
  	scanf("\n");
  	tenth();
  	printf("\n***11. program***\n");
  	eleventh();
  	printf("\n***12. program***\n");
  	twelfth();
  	printf("\n***13. program***\n");
  	thirteenth();
  	printf("\n");
  	return 0;
}
