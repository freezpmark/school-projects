#include <stdio.h>
#include <stdlib.h>

// vytvor
int b[100][100];
int d[4][2];

// vytvor bludisko b (vsade same steny)
void vytvor(int n)
{
	int i, j;
	for (i = 0; i < n; i++)
		for (j = 0; j < n; j++)
			b[i][j] = 15;
}

// vykresli bludisko b
void vykresli(int n)
{
	int i, j;
	i = 0;
	printf("#");
	for (j = 0; j < n; j++)
	{
		if (b[i][j] & 1) // horna stena v bludisku i,j ??
			printf("#");
		else
			printf(".");
		printf("#");
	}
	printf("\n");

	for (i = 0; i < n; i++) // riadok
	{
		// uroven miestnosti
		if (b[i][0] & 8)
			printf("#");
		else
			printf(".");

		for (j = 0; j < n; j++) // stlpec
		{
			printf(".");
			if (b[i][j] & 2)
				printf("#");
			else
				printf(".");
		}
		printf("\n");

		// uroven stien
		printf("#");
		for (j = 0; j < n; j++)
		{
			if (b[i][j] & 4) // dolna stena v bludisku i,j ??
				printf("#");
			else
				printf(".");
		printf("#");
	}
	printf("\n");
	}
}

// najst cestu -- pravidlo pravej ruky
int existuje_cesta(int n, int start_r, int start_s, int koniec_r, int koniec_s)
{
	int r = start_r, s = start_s, smer=0;
	int start_smer[4];
	start_smer[0] = start_smer[1] = start_smer[2] = start_smer[3] = 0;
	while(1)
	{
		if (r == koniec_r && s == koniec_s)
			break;
		if (b[r][s] == 15)
			return 0;
		int napravo = (smer+1)%4;
		int stena_napravo = 1<<napravo;
		int stena_dopredu = 1<<smer;
		// ked je napravo stena, pokracuj
		if (b[r][s] & stena_napravo)
		{
			if (b[r][s] & stena_dopredu)
			{
				// otoc dolava (+3)
				smer = (4+smer-1)%4;
			}
			else
			{
				// cyklim sa?
				if (r == start_r && s == start_s)
				{
					if (start_smer[smer] == 1)
						return 0;
					start_smer[smer] = 1;
				}
				// chod dopredu
				r += d[smer][0];
				s += d[smer][1];
			}
		}
		else
		{
			// napravo nie je stena
			smer = napravo; // otocit doprava

			if (r == start_r && s == start_s)
			{
				if (start_smer[smer] == 1)
					return 0;
				start_smer[smer] = 1;
			}

			// chod dopredu
			r += d[smer][0];
			s += d[smer][1];
		}
	}

	return 1; // nasli sme koniec
}

// vygenerovat
void generuj(int n)
{
	int x;
	for (x = 0; x < n*n*10; x++)
	{
		// nahodna miestnost
		int r = rand()%n;
		int s = rand()%n;
		// nahodny smer
		int smer = rand()%4;
		if (r == 0 && smer == 0)
			continue;
		if (r == n-1 && smer == 2)
			continue;
		if (s == 0 && smer == 3)
			continue;
  if (s == n-1 && smer == 1)
	  continue;
  int stena = 1<<smer; // hodnota steny v smere smer
  if (b[r][s] & stena) // je tam stena v smere 'smer'?
  {
	  // X = r,s
	  // Y = sused r,s
	  int r2 = r + d[smer][0];
	  int s2 = s + d[smer][1];

	  // NEexistuje cesta medze r,s, a r2,s2?
	  if (!existuje_cesta(n, r,s, r2,s2))
	  {
		  // preburame stenu
		  b[r][s] = b[r][s]^stena;
		  int opacny_smer = (smer + 2)%4;
		  b[r2][s2] = b[r2][s2]^(1<<opacny_smer);
		  //vykresli(n);
	  }
  }
	}

}

int main(void)
{

	// hore 1 << 0 == 1
	d[0][0] = -1;
	d[0][1] = 0;
	// 1=doprava 1<<1 == 2
	d[1][0] = 0;
	d[1][1] = 1;
	// 2=dole 1<<2 == 4
	d[2][0] = 1;
	d[2][1] = 0;
	// 3=dolava 1<<3 == 8
	d[3][0] = 0;
	d[3][1] = -1;

	int n = 15;
	vytvor(n);
	generuj(n);
	vykresli(n);
	return 0;
}