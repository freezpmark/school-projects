#include <stdio.h>

int main()
{
    FILE *fr1, *fr2, *fw;
    char a;
    int c = 1, d = 0, e = 0;
    fr1 = fopen("prvy.txt","r");
    fr2 = fopen("druhy.txt","r");
    fw = fopen("treti.txt","w");
    while ((d == 0) || (e == 0)) {
        if ((c % 2 == 1) && (d != 1)) {
            putc('+', fw);
            while (1) {
                a = getc(fr1);
                if (a == EOF) {
                    d = 1;
                    break;
                } else if ((a == '\n') || (a == ' ')) {
                    putc(' ', fw);
                    break;
                } else
                    putc(a, fw);
            }
        }
        else if ((c % 2 == 0) && (e != 1)) {
            putc('-', fw);
            while (1) {
                a = getc(fr2);
                if (a == EOF) {
                    e = 1;
                    putc(' ', fw);
                    break;
                } else if ((a == '\n') || (a == ' ')) {
                    putc(' ', fw);
                    break;
                } else
                    putc(a, fw);
            }
        }
        c++;
    }
    fclose(fr1);
    fclose(fr2);
    fclose(fw);
    return 0;
}
