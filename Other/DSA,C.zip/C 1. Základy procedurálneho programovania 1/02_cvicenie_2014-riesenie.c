#include <stdio.h>

void first() {
    char a;
  	scanf("%c", &a);
  	if (a >= '0' && a <= '9')
        printf("%c\n", a);
  	else
        printf("ZNAK\n");
  	(a >= '0' && a <= '9') ? printf("%c\n", a) : printf("ZNAK\n");
}

void second() {
    char a;
  	scanf("%c", &a);
    if ((a >= 'A' && a <= 'z') || (a >= '0' && a <= '9'))
        printf("Alfanumericky znak\n");
    else
        printf("Interpunkcny znak\n");
}

void third() {
    char a, b;
  	scanf("%c %c", &a, &b);
  	a += 'A' - 'a';
  	b += 'A' - 'a';
  	printf("%c %d\n%c %d\n", a, a, b, b);
}

void forth() {
    char a, b;
    scanf("%c %c", &a, &b);
    a += 'a' - 'A';
    b += 'a' - 'A';
    printf("%c %c\n", b, a);
}

void fifth() {
    float c, d;
  	scanf("%f", &c);
  	d = (c-32.)*(5./9.);
      printf("%.2f", d);
    if (d < 0)
        printf("\nMrzne\n");
    if (d >= 100)
        printf("\nVrie\n");
}

void sixth() {
    int c1, c2, c3, min;
    scanf("%d %d %d", &c1, &c2, &c3);
    if (c1 > c2)
        min = c2;
    else
        min = c1;
    if (min > c3)
        min = c3;
    printf("Najmensie cislo z %d %d %d je: %d\n", c1, c2, c3, min);
}

void seventh() {
    int e, f, g, pom;
    scanf("%d %d %d", &e, &f, &g);
    if (e > f) {
        pom = e;
        e = f;
        f = pom;
    }
    if (f > g) {
        pom = f;
        f = g;
        g = pom;
    }
    if (e > f) {
        pom = e;
        e = f;
        f = pom;
    }
  	printf("%d %d %d\n", e, f, g);
}

void eighth() {
    char a, b, z;
    scanf("%c %c %c", &a, &b, &z);
    if ((a == b) && (a == z))
        printf("Vsetky pismena su rovnake\n");
    if ((a != b) && (a != z) && ( b != z))
        printf("Vsetky pismena su rozne\n");
    if ((a == b || a == z || b == z) && (a != b || a != z || b != z))
        printf("Dve pismena su rovnake\n");
}

void ninth() {
    float vyska, vaha, BMI;
    scanf("%f %f", &vyska, &vaha);
    BMI = vaha / ((vyska/100) * (vyska/100));
  	if (BMI > 30)
		printf("BMI: %.3f\nObezita\n", BMI);
  	if (BMI > 25 && BMI < 30)
		printf("BMI: %.3f\nNadvaha\n", BMI);
	if (BMI > 18.5 && BMI < 25)
		printf("BMI: %.3f\nNormalna hmotnost\n", BMI);
	if (BMI <= 18.5)
    	printf("BMI: %.3f\nPodvaha\n", BMI);
}


int main()
{
    printf("***1. program***\n");
  	first();
  	printf("\n***2. program***\n");
  	scanf("\n");
  	second();
  	printf("\n***3. program***\n");
  	scanf("\n");
  	third();
  	printf("\n***4. program***\n");
  	scanf("\n");
  	forth();
  	printf("\n****5. program***\n");
  	scanf("\n");
  	fifth();
  	printf("\n***6. program***\n");
  	scanf("\n");
  	sixth();
  	printf("\n***7. program***\n");
  	scanf("\n");
  	seventh();
  	printf("\n***8. program***\n");
  	scanf("\n");
  	eighth();
  	printf("\n***9. program***\n");
  	scanf("\n");
  	ninth();
  	printf("\n\n");
  	return 0;
}
