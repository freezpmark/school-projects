/*
Daná je vzostupne usporiadaná postupnosť čísel, napíšte funkciu,
ktorá pre dané číslo X nájde jeho pozíciu v tejto postupnosti.
Ak sa číslo X v postupnosti nenachádza, funckia vráti -1.

Naprogramujte funkciu v nasledovnom tvare:

// vrati index cisla x vo vzostupne usporiadanej postupnosti cisel. Vrati -1 ak sa x v postupnosti nenachadza.
int search(int cisla[], int n, int x)
{
  // ...
}
*/


#include <stdio.h>
#include <stdlib.h>
// Funkcia vrati index cisla x vo vzostupne usporiadanej postupnosti cisel.
// Vrati -1 ak sa x v postupnosti nenachadza.

int search(int cisla[], int n, int x)	// pole cisel, pocet cisel, hladacie cislo
{
    int prvy = 0, posledny = (n-1);

    while(prvy <= posledny) {
        if (cisla[(prvy+posledny)/2] == x)
            return (prvy+posledny)/2;

        if (cisla[(prvy+posledny)/2] < x)
            prvy = (prvy+posledny)/2+1;
        else
            posledny = (prvy+posledny)/2-1;
    }

    return -1;
}


// ukazkovy test (spracovanie vstupu)
int main(void)
{
  int *a, n, i;

  scanf("%d", &n);
  a = (int*)malloc(n * sizeof(int));
  for (i = 0; i < n; i++)
    scanf("%d", &a[i]);

  while (scanf("%d", &i) > 0)
  	printf("Cislo %d je na pozicii %d\n", i, search(a, n, i));
  return 0;
}
