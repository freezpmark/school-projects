#include <stdio.h>
#include <stdlib.h>

/*
Napíšte algoritmus, ktorý nájde K-te (1 <= K <= 100 000)
prvočíslo v poradí od najmenších (pozn. prvé je 2).
Štandardný vstup obsahuje niekoľko riadkov, na každom z nich bude jedno číslo K.
Pre každý riadok na vstupe vypíšte na štandardný výstup práve jedno číslo -- K-te prvočíslo.
Pomôcka: Úlohu riešte Eratostenovým sitom. Pre zbehnutie v časovom limite je podstatné,
aby ste vo svojom algoritme nepoužívali operáciu delenia (resp. zvyšok po delení)
a veľa operacií násobenia (okrem prístupu do pola cez []). Používajte najmä sčítanie.
Ukážka vstupu:
1
2
3
4
10
Výstup pre ukážkový vstup:
2
3
5
7
29
*/


#define MAX 1300000
#include <stdio.h>

int main()
{
    int prvocisla[100050], i, j = 0, k, n;
    char pole[MAX];

    for (i = 0; i < MAX; i++)
        pole[i] = '1';

    for (i = 2; i < MAX; i++) {
        if (pole[i] == '1')
            prvocisla[j++] = i;
        for (k = 2*i; k < MAX; k+=i)
            pole[k] = '0';
    }

    while(scanf("%d", &n) > 0) {
        if (n >= 1 && n <= 100000)
            printf("%d\n", prvocisla[n-1]);
    }

    return 0;
}
