/*
Napíšte program, ktorý zo vstupu načíta neznámy počet mien kamarátov,
a následne načíta neznámy počet čísel. Pre každé číslo na vstupe vypíše
meno kamaráta na príslušnom mieste v usporiadanom poradí podľa abecedy (lexikograficky).
Ak sa kamarát s požadovaným číslom vo vstupe nenachádza vypíšte správu
Vstup neobsahuje prvok X, kde X je požadované číslo.

Štandardný vstup obsahuje niekoľko riadkov. Najskôr budú v riadkoch mená,
každé meno sa skladá so znakov anglickej abecedy, a može sa skladať z viacerých slov.
Po týchto menách budú nasledovať na vstupe čísla, pričom na jednom riadku može
byť jedno alebo aj viac čísel. Číslo predstavuje poradie kamaráta v usporiadanom poradí,
číslovanie abecedne najmenší od 1.

Pomôcka: Načítavajte po riadkoch mená, a v prípade, že natrafíte na čísla,
tak spracujte čísla podľa požiadaviek. Keďže vopred nevieme koľko mien bude na vstupe,
použite na načítanie spájaný zoznam.

Ukážka vstupu:
Janko
Marienka Pekna
Adam Mily
 2  1   100
3
Výstup pre ukážkový vstup:
Janko
Adam Mily
Vstup neobsahuje prvok 100
Marienka Pekna
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct prvok {
    char meno[256];
    struct prvok *dalsi;
} PRVOK;

PRVOK *zoznam, *akt, *po, *save;

int main()
{
    char *line, *number;
    line = malloc(256 * sizeof(char));
    int i, j, k = 0;

    while(gets(line)) {
        for (i = 0; line[i] != '\0'; i++) {
            if ((line[i] >= 'A') && (line[i] <= 'z')) {     // Nacitavanie abecedneho pismena
                save = malloc(sizeof(PRVOK));
                for(j = 0; line[i] != '\0'; i++, j++) {     // nacitanie slova s osetrenim cisla
                    if ((line[i] >= '0') && (line[i] <= '9'))
                        break;
                    save->meno[j] = line[i];
                }                if ((line[i] >= '0') && (line[i] <= '9'))
                    break;
                save->meno[j] = '\0';
                if (zoznam == NULL) {           // ak je prvy, ide do zoznamu
                    zoznam = save;
                    zoznam->dalsi = NULL;
                }
                else {
                    for (j = 0; zoznam->meno[j] == save->meno[j]; j++)      // porovnavanie s prvym
                            ;
                    if (zoznam->meno[j] > save->meno[j]) {
                        akt = zoznam;
                        zoznam = save;
                        zoznam->dalsi = akt;
                    }
                    else {
                        for (akt = zoznam; akt->dalsi != NULL; akt = akt->dalsi) {      // pridanie vntri zoznamu
                            for (j = 0; akt->dalsi->meno[j] == save->meno[j]; j++)
                                ;
                            if (akt->dalsi->meno[j] > save->meno[j]) {
                                po = akt->dalsi;
                                akt->dalsi = save;
                                save->dalsi = po;
                                break;
                            }
                        }
                        if (akt->dalsi == NULL) {    // pridanie posledneho
                            akt->dalsi = save;
                            save->dalsi = NULL;
                        }
                    }
                }
            }
            if (line[i] == '0')     // prve cislo ako nula nemoze byt
                continue;
            if ((line[i] >= '1') && (line[i] <= '9')) {
                if (zoznam == NULL)
                    printf("Niesu nacitane ziadne mena\n");
                for( ; line[i] != '\0'; i++) {      // NEFUNGUJE '\0' (citame do konca riadku)
                    if ((line[i] >= '0') && (line[i] <= '9')) {
                        number = malloc(5 * sizeof(char));
                 // viacciferne cisla kontrola
                        for (k = 0; ((line[i] >= '0') && (line[i] <= '9')); k++, i++) {
                            number[k] = line[i];
                        }
                        int integer = atoi(number);

                        for (akt = zoznam, j = 1; (j < integer) && (akt != NULL); j++, akt = akt->dalsi)
                            ;   // vypisanie zoznamu
                        if (akt == NULL)
                                 printf("Vstup neobsahuje prvok %d\n", integer);
                        if (akt != NULL)
                            printf("%s\n", akt->meno);
                        if (line[i] == '\0')
                            i--;
                        free(number);
                    }
                    else
                        continue;
                }
            }
            if (line[i] == '\0')
                break;
        }
    }
        return 0;
}
