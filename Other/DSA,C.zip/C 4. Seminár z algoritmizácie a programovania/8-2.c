#include <stdio.h>

// vypocita x^n
double xn(double x, int n)
{
  double new_x = x, final = 1;
  int new_n = n;
  while(new_n > 0) {
    if(new_n % 2 == 1)
    	final *= new_x;
    	new_x *= new_x;
    	new_n /= 2;
  }
  return final;
}

// spracovanie vstupu
int main(void)
{
  double x;
  int n;
  while (scanf("%lf %d", &x, &n) == 2)
    printf("%lf^%d = %lf\n", x, n, xn(x, n));
  return 0;
}
