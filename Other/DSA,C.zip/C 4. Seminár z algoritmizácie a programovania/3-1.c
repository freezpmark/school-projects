/*
Daný je strom (vrcholy a neorientované hrany medzi nimi) a dvojica vrcholov, vašou úlohou je zistiť vzdialenosť daných vrcholov v strome.
Vzdialenosť vrcholov je definovaná ako najkratšia cesta (postupnost hrán) medzi vrcholmi.

Špecifikácia vstupu: Prvý riadok vstupu obsahuje štyri čísla N (počet vrcholov stromu), M (počet hrán stromu), A (počiatočný vrchol), B (koncový vrchol).
Na nasledujúcich M riadkoch sú opísané (neorientované) hrany, každý z riadkov obsahuje tri čísla Xi, Yi, Li, reprezentujúce hranu medzi vrcholmi Xi a Yi s dĺžkou Li.

Špecifikácia výstupu: Na výstup napíšte jeden riadok obsahujúci jedno číslo – vzdialenosť vrcholov A a B v strome.

Ukážka vstupu:
4 3 1 4
1 2 10
2 3 20
2 4 30
Výstup pre ukážkový vstup:
40

POMOCKA:
Strom na vstupe reprezentujte ako zoznam spájaných zoznamov hrán pre každý vrchol.
Pre každý vrchol V máme spájaný zoznam hrán vychádzajúcich z vrchola V. Hranu v zozname si reprezentujeme ako dvojicu (cieľový vrchol, dĺžka).
Na začiatok načítavania inicilizujeme zoznam hrán každého vrchola na prázdny zoznam.
Pri načítaní neorientovanej hrany ju pridáme do zoznamov oboch jej koncových vrcholov.
Po načítaní môžeme dĺžku cesty medzi vrcholmi A a B hľadať rôznymi spôsobmi: rekurzívnou funkciou, využitím radu(frontu), a pod.
Každý vrchol stromu navštívime počas prehľadávania najviac raz.
Rekurzívna funkcia nám vráti dĺžku hľadanej cesty z aktuálneho vrchola (v) do cieľového vrchola (target), pričom bude mať tri vstupné parametre:
v: aktuálny vrchol prehľadávania
from: vrchol, z ktorého prehľadávanie prišlo do aktuálneho vrchola
target: vrchol, do ktorého hľadáme cestu
Telo rekurzívnej funkcie je jednoduché:
Ak aktuálny vrchol prehľadávania je cieľový vrchol, vráť 0. (dĺžka cesty z v do cieľového vrchola je 0)
Prejdi všetkých susedov aktuálneho vrchola (v), pričom neuvažujeme predchádzajúci vrchol (from):
ak existuje cesta zo susedného vrchola (next) do cieľa, tak vráť dĺžku tejto cesty zvýšenú o dĺžku hrany v-next.
Ak sme nenašli cestu cez žiadneho suseda, tak cesta z aktuálneho vrchola (v) do cieľového vrchola (target) neexistuje, a vráť -1.
Pre určenie dĺžky cesty medzi vrcholmi zadanými na vstupe stači zavolať vytvorenú rekurzívnu funkciu s vhodnými parametrami.
*/

#include <stdio.h>
#include <stdlib.h>

typedef struct VRCHOL {
	int pocetsusedov, sused[100], vzdialenost[100];
} VRCHOL;

void check(VRCHOL vr[], int index1, int index2, int b, int finished, int counter, int mother) {
	while((!finished) && (vr[index1].sused[index2] != -1)) {
		if(vr[index1].sused[index2] == b) {
			finished = 1;
			counter += vr[index1].vzdialenost[index2];
			printf("%d\n", counter);
			break;
		}
		else if(vr[index1].sused[index2] != mother) {
			mother = index1;
			check(vr, vr[index1].sused[index2], 0, b, finished, counter + vr[index1].vzdialenost[index2], mother);
		}
		index2++;
	}
}

int main()
{
	int i, j;
	int n, m, a, b;
	scanf("%d %d %d %d", &n, &m, &a, &b);
	VRCHOL *v;
	v = (VRCHOL *) malloc(n * sizeof(VRCHOL));
	for(i = 0; i < n; i++) {
		v[i].pocetsusedov = 0;
		for(j = 0; j < 100; j++) {
			v[i].sused[j] = -1;
			v[i].vzdialenost[j] = 0;
		}
	}
	int cislo1, cislo2, cislo3;
	for(i = 0;i < m; i++) {
		scanf("%d %d %d", &cislo1, &cislo2, &cislo3);
		v[cislo1 - 1].pocetsusedov++;
		v[cislo1 - 1].sused[v[cislo1 - 1].pocetsusedov - 1] = cislo2 - 1;
		v[cislo1 - 1].vzdialenost[v[cislo1 - 1].pocetsusedov - 1] = cislo3;

		v[cislo2 - 1].pocetsusedov++;
		v[cislo2 - 1].sused[v[cislo2 - 1].pocetsusedov - 1] = cislo1 - 1;
		v[cislo2 - 1].vzdialenost[v[cislo2 - 1].pocetsusedov - 1] = cislo3;
	}
	int counter = 0;
	check(v, a - 1, 0, b - 1, 0, counter, -2);
	return 0;
}
