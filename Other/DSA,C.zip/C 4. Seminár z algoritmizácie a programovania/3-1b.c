#include <stdio.h>

#define GRAF 5000

int vzdial[GRAF][GRAF]; 	// vzdialenost hranolu
int dlzka[GRAF]; 		// dlzka najkratsej cesty

void hladaj(int A, int N, int B) {
    int i, j, kratky;
    int seen[GRAF];

    for (i = 1; i <= N; ++i) {
        dlzka[i] = GRAF;
        seen[i] = 0;    // vsetky vrcholy neboli videne
    }
    dlzka[A] = 0;

    for (j = 1; j <= N; ++j) {      // vyhladavanie
        kratky = -1;
        for (i = 1; i <= N; ++i)
            if (!seen[i] && ((kratky == -1) || (dlzka[i] < dlzka[kratky])))
                kratky = i;

        seen[kratky] = 1;

        for (i = 1; i <= N; ++i) {
            if (vzdial[kratky][i])
                if (dlzka[i] > dlzka[kratky] + vzdial[kratky][i])
                    dlzka[i] = dlzka[kratky] + vzdial[kratky][i];
        }
    }
}

int main() {
    int i, j;       // iteratory
    int X, Y, L;    // neorientovane hrany
    int N, M, A, B; // pocet vrcholov, pocet hran, start, koniec

    scanf("%d %d %d %d", &N, &M, &A, &B);
    for (i = 0; i < M; ++i)
        for (j = 0; j < M; ++j)
            vzdial[i][j] = 0;

    for (i = 0; i < M; ++i) {
        scanf("%d %d %d", &X, &Y, &L);
        vzdial[X][Y] = L;
      	vzdial[Y][X] = L;   // kvoli obojsmernosti
    }

    hladaj(A, N, B);

    if (dlzka[B] == GRAF)   // ak nenaslo, vrati -1
    	return -1;
    else
        printf("%d", dlzka[B]);
    return 0;
}
