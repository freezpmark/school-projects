/*
Uvažujte binárny vyhľadávací strom. Na vstupe je daných niekoľko čísel,
ktoré postupne vkladáte do tohto stromu. Pre každé číslo zistite,
ako hlboko je v strome uložené. Ak sa číslo v strome nenachádza, tak ho najprv pridajte do stromu.

Špecifikácia vstupu: Na vstupe je niekoľko čísel, ktoré postupne vkladáte do stromu.
Čísla sú oddelené medzerou alebo novým riadkom.

Špecifikácia výstupu: Pre každé číslo na vstupe vypíšte jedno číslo -- ako hlboko je dané číslo uložené v strome.

Ukážka vstupu:
5
3
2
1
3
Výstup pre ukážkový vstup:
0
1
2
3
1

*/

#include <stdio.h>
#include <stdlib.h>

typedef struct strom {
  struct vrchol *koren;
};

typedef struct vrchol {
  int hodnota;
  struct vrchol *lavy, *pravy;
};


int main()
{
  struct strom *s = malloc(sizeof(struct strom));
  s->koren = NULL;

  int cislo, hlbka;

  while(scanf("%d", &cislo) > 0) {
    hlbka = 0;

    if (s->koren == NULL) {
    	s->koren = malloc(sizeof(struct vrchol));
    	s->koren->hodnota = cislo;
    	s->koren->lavy = NULL;
    	s->koren->pravy = NULL;
      printf("%d\n", hlbka);
    }
  	else {
    	struct vrchol *akt = malloc(sizeof(struct vrchol));
    	akt = s->koren;

    	while (1) {
        	if (akt->hodnota == cislo) {
            	printf("%d\n", hlbka);
            	break;
            }
            else if (akt->hodnota > cislo) {
            	if (akt->lavy == NULL) {
              		akt->lavy = malloc(sizeof(struct vrchol));
              		akt->lavy->hodnota = cislo;
              		printf("%d\n", ++hlbka);
              		break;
            	}
            	else {
              		akt = akt->lavy;
              		hlbka++;
            	}

            }
          	else {
          		if (akt->pravy == NULL) {
            		akt->pravy = malloc(sizeof(struct vrchol));
              		akt->pravy->hodnota = cislo;
              		printf("%d\n", ++hlbka);
              		break;
            	}
            	else {
              		akt = akt->pravy;
              		hlbka++;
            	}
          	}
        }
  	}
  }
  return 0;
}
