/*
Uvažujte binárny vyhľadávací tree. Na vstupe je daných niekoľko čísel,
ktoré postupne vkladáte do tohto treeu. Pre každé číslo zistite,
ako hlboko je v treee uložené. Ak sa číslo v treee nenachádza, tak ho najprv pridajte do treeu.

Špecifikácia vstupu: Na vstupe je niekoľko čísel, ktoré postupne vkladáte do treeu.
Čísla sú oddelené medzerou alebo novým riadkom.

Špecifikácia výstupu: Pre každé číslo na vstupe vypíšte jedno číslo -- ako hlboko je dané číslo uložené v treee.

Ukážka vstupu:
5
3
2
1
3
Výstup pre ukážkový vstup:
0
1
2
3
1

*/

#include <stdio.h>
#include <stdlib.h>

 struct tree {
  struct point *root;
};

 struct point {
  int value;
  struct point *left, *right;
};

int main()
{
  struct tree *s = malloc(sizeof(struct tree));
  s->root = NULL;

  int cislo, depth;
  while(scanf("%d", &cislo) > 0) {
    depth = 0;

    if (s->root == NULL) {
    	s->root = malloc(sizeof(struct point));
    	s->root->value = cislo;
    	s->root->left = NULL;
    	s->root->right = NULL;
      printf("%d\n", depth);
    }
  	else {
    	struct point *act = malloc(sizeof(struct point));
    	act = s->root;

    	while (1) {
        	if (act->value == cislo) {
            	printf("%d\n", depth);
            	break;
            }
            else if (act->value > cislo) {
            	if (act->right == NULL) {
            		act->right = malloc(sizeof(struct point));
              		act->right->value = cislo;
              		printf("%d\n", ++depth);
              		break;
            	}
            	else {
              		act = act->right;
              		depth++;
            	}
            }
          	else {
                if (act->left == NULL) {
              		act->left = malloc(sizeof(struct point));
              		act->left->value = cislo;
              		printf("%d\n", ++depth);
              		break;
            	}
            	else {
              		act = act->left;
              		depth++;
            	}
          	}
        }
  	}
  }
  return 0;
}
