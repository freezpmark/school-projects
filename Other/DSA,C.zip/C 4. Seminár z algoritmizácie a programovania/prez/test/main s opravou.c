#include <stdio.h>

int citaj(int *pole)
{
    int N, a;
    scanf("%d", &N);
    if (N > 20) {
        printf("Nespravny pocet prvkov pola\n");
        return 0;
    }
    for (a = 0; a < N; a++) {
        scanf("%d", &pole[a]);
        if (pole[a] > 999)
            pole[a] %= 1000;
        printf("%d ", pole[a]);
    }
    putchar('\n');
    return N;
}

void najdi_podpost(int *pole, int pocet)
{
    int b = 0, a;
    int max = 0; // dlzka retazca, ktory ma najviac parnych cisiel za sebou
    int zaciatok = 0; // ziaciatocny index retazca, ktory ma najviac parnych cisiel za sebou

    for (a = 0; a < pocet; a++) {
        if (pole[a] % 2 == 0) {
            b++;
            if (b > max) { // nasli sme este dlhsi retazec
                zaciatok = a - b + 1;
                max = b;
            }
        }
        else {
            b = 0;
        }
    }
    for (a = zaciatok; a < zaciatok + max; a++)
        printf("%d ", pole[a]);
    putchar('\n');
}

void kresli(int *pole, int pocet)
{
    int r, s, c;

    for (r = 1; r <= pocet*2-1; r++) {
        c = 0;
        for (s = 1; s <= pocet; s++, c++) {
            if ((r >= s) && (r+s <= pocet*2))
                printf("%3d", pole[c]);
            else
                printf("...");
            if (s != pocet)
            putchar('.');
        }
        putchar('\n');
    }
}

int main()
{
    int pocet, pole[20];
    pocet = citaj(pole);
    if (pocet == 0)
        return 1;
    najdi_podpost(pole, pocet);
    kresli(pole, pocet);
    return 0;
}
