#include <stdio.h>
#include <stdlib.h>

int citaj(int *pole)
{
    int n, a;
    scanf("%d", &n);
    if (n > 20) {
        printf("Nespravny pocet prvkov pola\n");
        return 0;
    }
    for (a = 0; a < n; a++) {
        scanf("%d", &pole[a]);
        if (pole[a] > 999)
            pole[a] %= 1000;
        printf("%d ", pole[a]);
    }
    putchar('\n');
    return n;
}

void najdi_podpost(int *pole, int pocet)
{
    int b = 0, a, c, podpost[pocet];
    for (a = 0; a < pocet; a++) {
        if (pole[a] % 2 == 0) {
            podpost[b] = pole[a];
            b++;
        }
       else
            for (c = 0; c < b; c++) {
                printf("%d ", podpost[c]);
            }
    }
    putchar('\n');
}

void kresli(int *pole, int pocet)
{
    int riadok, stlpec, c;
    for (riadok = 1; riadok <= pocet*2-1; riadok++) {
        c = 0;
        for (stlpec = 1; stlpec <= pocet; stlpec++, c++) {
            if ((riadok >= stlpec) && (riadok+stlpec <= pocet*2))
                printf("%3d", pole[c]);
            else
                printf("...");
            if (stlpec != pocet)
            putchar('.');

        }
        putchar('\n');
    }
}

int main()
{
    int pocet, pole[20];
    pocet = citaj(pole);
        if (pocet == 0)
            return 1;
    najdi_podpost(pole, pocet);
    kresli(pole, pocet);
    return 0;
}
