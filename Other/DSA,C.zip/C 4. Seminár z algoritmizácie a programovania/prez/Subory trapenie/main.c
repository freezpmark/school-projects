#include <stdio.h>
int main()
{
  FILE *fr1, *fr2, *fw;
  char znak;
  int slovo = 1, prvy = 1, druhy = 1;
  fr1 = fopen("prvy.txt","r"); fr2 = fopen("druhy.txt","r"); fw = fopen("treti.txt","w");

while ((prvy == 1) || (druhy == 1)) {   // Prvy alebo druhy subor obsahuje znaky na citanie

    if ((slovo % 2 == 1) && (prvy != 0)) {   // Neparne slovo a ma co citat z prveho suboru
        putc('+', fw);
        while (1) {
                znak = getc(fr1);
            if (znak == EOF) {
                prvy = 0;
                putc(' ', fw);
                break; }
            else if ((znak == '\n') || (znak == ' ')) {
                putc(' ', fw);
                break; }
            else
                putc(znak, fw);
        }
    }
    else if ((slovo % 2 == 0) && (druhy != 0)) { //
        putc('-', fw);
        while (1) {
                znak = getc(fr2);
            if (znak == EOF) {
                druhy = 0;
                putc(' ', fw);
                break; }
            else if ((znak == '\n') || (znak == ' ')) {
                putc(' ', fw);
                break; }
            else
                putc(znak, fw);
        }
    }
    slovo++;
}
  fclose(fr1); fclose(fr2); fclose(fw);
  return 0;
}
