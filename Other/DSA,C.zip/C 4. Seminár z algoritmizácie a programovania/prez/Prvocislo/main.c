#include <stdio.h>

int main()
{
int pole[1000];
int i, k;
for (i = 0; i < 1000; i++)
    pole[i] = 1;
pole[0] = 0;
pole[1] = 0;
for (i = 0; i < 1000; i++) {
    if (pole[i] == 1) {
        printf("%d\n",i);
        for (k = 2*i; k < 1000; k = k + i)
            pole[k] = 0;
    }
}
    return 0;
}
