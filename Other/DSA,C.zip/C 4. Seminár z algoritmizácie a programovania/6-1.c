/*
Určite ste to už zažili... večer, diskotéka, pri vchode sympatickí vyhadzovači
nekompromisne odmietajú vstup neplnoletým mládežníkom, ktorí sa už nedočkavo tlačia na parket.
Mladí ale vedia byť vynaliezaví, zaobstarali si občiansky preukaz so “správnym”
dátumom narodenia a po prekonaní poslednej prekážky si ho poza chrbát posunú spať
a na vstupe je opäť použitý ďalším nedočkavcom. Takto to ale nemôže ísť ďalej!!
Pomôžte ochrániť zdravý morálny vývin našej mládeže a pomôžte vyhadzovačom identifikovať preukazy,
ktoré boli na vstup už raz použité.

Na vstupe je daná postupnosť čísel občianskych preukazov, v poradí ako sa nimi návštevníci preukazujú.
Vašou úlohou je zistiť počet, koľko z nich sa pokúšali použiť opakovane.
Číslo OP je reťazec čísel a písmen, môžu byť rôzne dlhé. Riešenie musí pracovať
v optimálnej očakávanej časovej zložitosti O(N), kde N je počet čísel občianskych preukazov na vstupe.

Naprogramujte funkciu v nasledovnom tvare:

// spracuje cisla OP: vrati pocet najdenych duplikatov.
int vyhadzovac(char *a[], int n)
{
  // ...
}
Poznámka: Všetky potrebné operácie by ste mali implementovať vlastnými silami.
Pomalšie ako optimálne lineárne riešenie nesplní časový limit v testovači.

Napr. pre čísla OP:
AA123456
BA987689
AA123123
AA312312
BB345345
AA123123
je
Pocet duplikatov: 1

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// spracuje cisla OP: vrati pocet najdenych duplikatov.
int vyhadzovac(char *a[], int n) //pole OP, pocet OP
{
  int i, j, dlzka, pocet = 2*n+1, duplikat = 0;
  long long cislo;
  char **pole = malloc(pocet * sizeof(char*));

  for(i = 0; i < n; i++) {  	// konverzia kodu na int a pomocne pole char
    cislo = 0;
    char pom[250];
    dlzka = strlen(a[i]);
    for(j = 0; j < dlzka; j++) {
      cislo = 13*cislo + a[i][j];			// cislo kodu
      pom[j] = a[i][j];						// chary kodu
    }
    pom[dlzka] = 0;
    cislo %= pocet;							// cislo == index v poli

    while(1) {

      if(pole[cislo] == NULL) {		// ak tam nieje, pridame
        pole[cislo] = malloc(dlzka * sizeof(char));
		strcpy(pole[cislo], pom);
        break;
      }
      else {
        if(!strcmp(pole[cislo], pom)) {
          duplikat++;
          break;
        }
        else {
          cislo++;
          if(cislo >= pocet)		// posunutie na zaciatok pola pri konci pola
        	cislo = 0;
    	}
      }
    }
  }
  return duplikat;
}


// ukazkovy test
int main(void)
{
  char **a = NULL, buf[100];
  int n = 0, len = 0;

  // nacitanie retazcov
  while(scanf("%s", buf) > 0) {
    if (n == len) {
      len = len + len + (len==0);
      a = (char**)realloc(a, len*sizeof(char*));
    }
    a[n++] = strdup(buf);
  }

  printf("Pocet duplikatov: %d\n", vyhadzovac(a, n));
  return 0;
}
