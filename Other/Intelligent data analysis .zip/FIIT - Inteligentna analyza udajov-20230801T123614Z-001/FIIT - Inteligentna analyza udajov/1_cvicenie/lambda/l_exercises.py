# Lambda funkcie
#
# Tato sekcia sluzi na precvicenie si lambda vyrazov
#

# Uloha 1:
def make_square():
    pass


# Uloha 2:
def make_upper():
    pass


# Uloha 3:
def make_power():
    pass


# Uloha 4:
def make_power2(N):
    pass


# Uloha 5:
def call_name():
    pass