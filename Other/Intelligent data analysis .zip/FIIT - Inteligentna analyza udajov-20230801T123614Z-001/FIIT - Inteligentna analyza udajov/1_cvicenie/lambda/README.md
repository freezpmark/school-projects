# Zoznam príkladov na precvičenie si lambda výrazov
[english version](README_EN.md)

Tychto prikladov je len velmi malo. 
Lambda vyrazy sa pouzivaju aj v prikladoch k funkciam vyssej urovne a k spracovaniu zoznamu, takze zaujemcom odporucam poziet sa na tie.

1. Napíšte funkciu, ktorá vracia lambda výraz, ktorý počíta druhú mocninu čísla, ktoré dostáva ako parameter. 
Funkcia samotná nedostáva žiadne parametre.

2. Napiste funkciu, ktora vracia lambda vyraz, ktory vrati retazec (prijaty ako parameter) transformovany na velke pismena.

3. Napiste funkciu, kora vracia lambda vyraz vypocitavajuci N-tu mocninu cisla, ktore dostava ako parameter. 
Lambda vyraz dostava dva parametre: cislo, ktore chceme umocnit a mocnitel. 

4. Napiste funkciu, kora vracia lambda vyraz vypocitavajuci N-tu mocninu cisla, ktore dostava ako parameter. 
Cislo N je parametrom funkcie, nie lambda vyrazu.

5. Napiste funkciu, ktora vracia lambda vyraz, ktory zavola nad objektom funkciu, ktoru dostane druhym parametrom v podobe retazca
[pomocka](https://docs.python.org/3/library/functions.html#getattr)
