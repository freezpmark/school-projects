import operator as op
from functools import reduce
import re
import math
import collections as col

# Uloha 1:
def square(iterable):
    pass


# Uloha 2:
def even(iterable):
    pass


# Uloha 3:
def to_fahrenheit(iterable):
    pass


# Uloha 4:
def arthur_speaking(file_path):
    pass


# Uloha 5:
def arthur_speaking_clear(file_path):
    pass


# Uloha 6:
def line_count(file_path):
    pass


# Uloha 7:
def word_count(file_path):
    pass


# Uloha 8:
def total_words(file_path):
    pass


# Uloha 9:
def my_max(iterable):
    pass


# Uloha 10:
def my_mean(iterable):
    pass


# Uloha 11:
def my_std(iterable):
    pass

# Uloha 12:
def flatten(iterable):
    pass

# Uloha 13:
def histogram(file_path):
    pass
