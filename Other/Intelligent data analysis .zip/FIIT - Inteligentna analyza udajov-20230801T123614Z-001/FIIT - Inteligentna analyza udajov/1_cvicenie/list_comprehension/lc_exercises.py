# Praca so zoznamom
#
# Tato sekcia sluzi na precvicenie si pace so zoznamom
#

# Pristupovanie k prvkom zoznamu
# Uloha 1:
def first(list):
    pass


# Uloha 2:
def last(list):
    pass


# Uloha 3:
def interval(list, a, b):
    pass


# Uloha 4:
def no_first_two(list):
    pass


# Uloha 5:
def no_last_three(list):
    pass


# Uloha 6:
def every_second(list):
    pass

# List comprehension
# Uloha 7:

def square(list):
    pass


# Uloha 8:
def plus_one(list):
    pass


# Uloha 9:
def evens(list):
    pass


# Uloha 10:
def multiples(N):
    pass


# Uloha 11:
def first_chars(phrase):
    pass


# Uloha 12:
def unique_consonants(phrase):
    pass


# Uloha 13:
def replace_vowels(phrase):
    pass


# Uloha 14:
def word_combinations(list1, list2):
    pass


# Uloha 15:
def two_dices():
    pass


# Uloha 16:
def array(dim1, dim2, init=None):
    pass


# Uloha 17:
def combinations_of_two(list):
    pass


# Uloha 18:
def combinations_of_two_no_rep(list):
    pass


# Uloha 19:
def pytagoreans(N):
    pass


