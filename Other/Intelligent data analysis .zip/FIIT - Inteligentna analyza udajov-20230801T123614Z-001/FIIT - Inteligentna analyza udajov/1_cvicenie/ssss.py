
import string

#generalize = str.maketrans('', '', string.punctuation)

phrase = "aeiouy"
phrase2 = "dsasc"

print(lambda phrase: not set('abcdefghijklmnopqrstuvwxyz') - set(phrase.lower()))



#print("Dammit, I'm mad!"[::-1].translate(generalize).lower().replace(" ", ""))
#print("Dammit, I'm mad!".translate(generalize).lower().replace(" ", ""))